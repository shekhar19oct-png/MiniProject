from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from utils.segment import DEFAULT_SECTIONS, parse_section_definition


def _env_flag(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


@dataclass
class AuditConfig:
    design_image: Path
    website_image: Path | None
    website_url: str | None
    output_dir: Path
    project_name: str
    target_name: str
    model_name: str = "gemini-2.5-flash"
    llm_enabled: bool = True
    require_llm: bool = field(default_factory=lambda: _env_flag("AUDITOR_REQUIRE_LLM"))
    capture_enabled: bool = False
    max_findings_per_section: int = 4
    section_definitions: list[tuple[str, float, float]] = field(
        default_factory=lambda: list(DEFAULT_SECTIONS)
    )
    api_key: str | None = field(
        default_factory=lambda: os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    )

    @classmethod
    def from_inputs(
        cls,
        design_image: Path,
        website_image: Path | None,
        website_url: str | None,
        output_dir: Path,
        project_name: str,
        target_name: str,
        model_name: str,
        llm_enabled: bool,
        require_llm: bool,
        capture_enabled: bool,
        custom_sections: list[str],
        max_findings_per_section: int,
    ) -> "AuditConfig":
        sections = (
            [parse_section_definition(raw) for raw in custom_sections]
            if custom_sections
            else list(DEFAULT_SECTIONS)
        )
        config = cls(
            design_image=design_image,
            website_image=website_image,
            website_url=website_url,
            output_dir=output_dir,
            project_name=project_name,
            target_name=target_name,
            model_name=model_name,
            llm_enabled=llm_enabled,
            require_llm=require_llm,
            capture_enabled=capture_enabled,
            max_findings_per_section=max(1, max_findings_per_section),
            section_definitions=sections,
        )
        config.validate()
        config.ensure_directories()
        return config

    @property
    def temp_dir(self) -> Path:
        return self.output_dir / "temp"

    def validate(self) -> None:
        if not self.design_image.exists():
            raise FileNotFoundError(f"Design image not found: {self.design_image}")

        if self.require_llm and not self.llm_enabled:
            raise ValueError("--require-llm cannot be combined with --disable-llm.")

        if not self.website_image and not self.website_url:
            raise ValueError("Provide either --website-image or --website-url.")

        if self.website_image and not self.capture_enabled and not self.website_image.exists():
            raise FileNotFoundError(f"Website image not found: {self.website_image}")

        if self.capture_enabled and not self.website_url:
            raise ValueError("--capture requires --website-url.")

    def ensure_directories(self) -> None:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir.mkdir(parents=True, exist_ok=True)
