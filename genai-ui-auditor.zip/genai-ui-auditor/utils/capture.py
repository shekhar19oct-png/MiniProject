from __future__ import annotations

from pathlib import Path


def capture_website(url: str, path: str | Path = "images/website.png") -> Path:
    try:
        from selenium import webdriver  # type: ignore
        from selenium.webdriver.chrome.options import Options  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "Selenium is not installed. Use --website-image for offline mode or install requirements first."
        ) from exc

    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    options = Options()
    options.add_argument("--headless=new")
    options.add_argument("--window-size=1600,2200")

    driver = webdriver.Chrome(options=options)
    try:
        driver.get(url)
        driver.save_screenshot(str(output_path))
    finally:
        driver.quit()

    return output_path
