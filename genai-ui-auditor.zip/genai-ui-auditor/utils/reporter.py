from __future__ import annotations

import html
import json
import re
from pathlib import Path

from utils.models import AuditReport, Finding, SectionAudit


def generate(report: AuditReport, output_dir: str | Path) -> dict[str, str]:
    base_dir = Path(output_dir)
    base_dir.mkdir(parents=True, exist_ok=True)

    json_path = base_dir / "report.json"
    markdown_path = base_dir / "report.md"
    html_path = base_dir / "report.html"
    tickets_dir = base_dir / "bug_tickets"
    tickets_dir.mkdir(parents=True, exist_ok=True)

    artifacts = {
        "json_report": str(json_path.resolve()),
        "markdown_report": str(markdown_path.resolve()),
        "html_report": str(html_path.resolve()),
        "bug_tickets_dir": str(tickets_dir.resolve()),
    }
    report.artifacts = artifacts

    json_path.write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")
    markdown_path.write_text(_render_markdown(report), encoding="utf-8")
    html_path.write_text(_render_html(report), encoding="utf-8")

    for section in report.sections:
        for finding in section.findings:
            if finding.severity in {"medium", "high", "critical"}:
                ticket_path = tickets_dir / f"{_slugify(finding.finding_id)}.md"
                ticket_path.write_text(
                    _render_ticket(section, finding),
                    encoding="utf-8",
                )

    return artifacts


def _render_markdown(report: AuditReport) -> str:
    lines = [
        f"# {report.project}",
        "",
        "## Summary",
        f"- Generated at: {report.generated_at}",
        f"- Sections audited: {report.summary.total_sections}",
        f"- Findings raised: {report.summary.total_findings}",
        f"- Highest severity: {report.summary.highest_severity}",
        f"- Risk score: {report.summary.risk_score}/100",
        f"- Release recommendation: {report.summary.release_recommendation}",
        "",
        "## QA Handoff",
    ]
    for item in report.qa_handoff.get("exploratory_focus", []):
        lines.append(f"- Exploratory focus: {item}")
    for item in report.qa_handoff.get("regression_suite_additions", []):
        lines.append(f"- Regression suite addition: {item}")
    for item in report.qa_handoff.get("manual_checks", []):
        lines.append(f"- Manual check: {item}")

    for section in report.sections:
        lines.extend(
            [
                "",
                f"## Section: {section.name.title()}",
                f"- Summary: {section.heuristic_summary}",
                f"- Similarity score: {section.metrics.similarity_score}",
                f"- Pixel difference: {section.metrics.pixel_difference}",
                f"- Color shift: {section.metrics.average_color_shift}",
                f"- Brightness shift: {section.metrics.brightness_shift}",
                f"- Edge density delta: {section.metrics.edge_density_delta}",
            ]
        )
        for note in section.qa_notes:
            lines.append(f"- QA note: {note}")
        for finding in section.findings:
            lines.extend(_finding_markdown(finding))

    return "\n".join(lines) + "\n"


def _finding_markdown(finding: Finding) -> list[str]:
    lines = [
        f"- Finding [{finding.severity.upper()}]: {finding.title}",
        f"- Category: {finding.category}",
        f"- Confidence: {finding.confidence}",
        f"- Impact: {finding.impact}",
    ]
    for evidence in finding.evidence:
        lines.append(f"- Evidence: {evidence}")
    for suggestion in finding.suggestions:
        lines.append(f"- Suggestion: {suggestion}")
    for idea in finding.test_ideas:
        lines.append(f"- Test idea: {idea}")
    for idea in finding.automation_ideas:
        lines.append(f"- Automation idea: {idea}")
    return lines


def _render_ticket(section: SectionAudit, finding: Finding) -> str:
    bug_ticket = finding.bug_ticket
    lines = [
        f"# {finding.title}",
        "",
        f"- Section: {section.name}",
        f"- Severity: {finding.severity}",
        f"- Category: {finding.category}",
        f"- Confidence: {finding.confidence}",
        "",
        "## Impact",
        finding.impact,
        "",
        "## Evidence",
    ]
    for item in finding.evidence:
        lines.append(f"- {item}")
    lines.extend(["", "## Reproduction Steps"])
    for item in bug_ticket.reproduction_steps if bug_ticket else []:
        lines.append(f"- {item}")
    lines.extend(["", "## Acceptance Checks"])
    for item in bug_ticket.acceptance_checks if bug_ticket else []:
        lines.append(f"- {item}")
    lines.extend(["", "## Fix Suggestions"])
    for item in finding.suggestions:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"


def _render_html(report: AuditReport) -> str:
    cards = []
    for section in report.sections:
        findings_html = "".join(
            f"""
            <li>
              <strong>{html.escape(finding.title)}</strong>
              <span class="severity severity-{html.escape(finding.severity)}">{html.escape(finding.severity)}</span>
              <p>{html.escape(finding.impact)}</p>
            </li>
            """
            for finding in section.findings
        )
        notes_html = "".join(f"<li>{html.escape(note)}</li>" for note in section.qa_notes)
        cards.append(
            f"""
            <section class="card">
              <h2>{html.escape(section.name.title())}</h2>
              <p>{html.escape(section.heuristic_summary)}</p>
              <ul>{findings_html}</ul>
              <h3>QA Notes</h3>
              <ul>{notes_html}</ul>
            </section>
            """
        )

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>{html.escape(report.project)}</title>
  <style>
    :root {{
      --bg: #f4efe8;
      --panel: #fffdf9;
      --text: #1f2430;
      --accent: #1f6feb;
      --warn: #d97706;
      --high: #b42318;
      --low: #2f855a;
      --border: #d9cfc2;
    }}
    body {{
      margin: 0;
      font-family: "Avenir Next", "Segoe UI", sans-serif;
      background:
        radial-gradient(circle at top right, rgba(31, 111, 235, 0.14), transparent 24%),
        linear-gradient(180deg, #f9f4ee 0%, var(--bg) 100%);
      color: var(--text);
    }}
    main {{
      max-width: 1080px;
      margin: 0 auto;
      padding: 40px 20px 64px;
    }}
    .hero {{
      background: rgba(255, 253, 249, 0.88);
      border: 1px solid var(--border);
      border-radius: 24px;
      padding: 28px;
      box-shadow: 0 16px 40px rgba(20, 22, 30, 0.08);
      margin-bottom: 24px;
    }}
    .grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 18px;
    }}
    .card {{
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 20px;
      box-shadow: 0 10px 30px rgba(31, 36, 48, 0.06);
    }}
    .severity {{
      display: inline-block;
      margin-left: 8px;
      padding: 2px 8px;
      border-radius: 999px;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      background: #edf2f7;
    }}
    .severity-high, .severity-critical {{
      background: rgba(180, 35, 24, 0.12);
      color: var(--high);
    }}
    .severity-medium {{
      background: rgba(217, 119, 6, 0.12);
      color: var(--warn);
    }}
    .severity-low {{
      background: rgba(47, 133, 90, 0.12);
      color: var(--low);
    }}
    ul {{
      padding-left: 18px;
    }}
  </style>
</head>
<body>
  <main>
    <section class="hero">
      <h1>{html.escape(report.project)}</h1>
      <p>Risk score: <strong>{report.summary.risk_score}/100</strong></p>
      <p>Release recommendation: {html.escape(report.summary.release_recommendation)}</p>
      <p>Highest severity: {html.escape(report.summary.highest_severity)}</p>
    </section>
    <div class="grid">
      {''.join(cards)}
    </div>
  </main>
</body>
</html>
"""


def _slugify(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]+", "-", value).strip("-").lower()
