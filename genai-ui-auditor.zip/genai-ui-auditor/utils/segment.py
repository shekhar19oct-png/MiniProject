from __future__ import annotations

from utils.image_tools import ImageData, get_section


DEFAULT_SECTIONS = [
    ("header", 0.0, 0.18),
    ("hero", 0.18, 0.52),
    ("body", 0.52, 0.88),
    ("footer", 0.88, 1.0),
]


def parse_section_definition(raw: str) -> tuple[str, float, float]:
    try:
        name, start, end = raw.split(":")
        start_ratio = float(start)
        end_ratio = float(end)
    except ValueError as exc:
        raise ValueError(
            f"Invalid --section value '{raw}'. Use name:start_ratio:end_ratio."
        ) from exc

    if not 0 <= start_ratio < end_ratio <= 1:
        raise ValueError(
            f"Section '{raw}' must satisfy 0 <= start < end <= 1."
        )
    return (name.strip(), start_ratio, end_ratio)


def split_sections(img: ImageData) -> dict[str, object]:
    return {
        name: get_section(img, name, start, end)
        for name, start, end in DEFAULT_SECTIONS
    }
