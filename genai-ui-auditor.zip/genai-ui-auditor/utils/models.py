from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


SEVERITY_RANK = {
    "info": 0,
    "low": 1,
    "medium": 2,
    "high": 3,
    "critical": 4,
}


@dataclass
class BugTicket:
    title: str
    severity: str
    reproduction_steps: list[str] = field(default_factory=list)
    acceptance_checks: list[str] = field(default_factory=list)


@dataclass
class Finding:
    finding_id: str
    title: str
    category: str
    severity: str
    confidence: float
    impact: str
    evidence: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    test_ideas: list[str] = field(default_factory=list)
    automation_ideas: list[str] = field(default_factory=list)
    bug_ticket: BugTicket | None = None
    source: str = "heuristic"


@dataclass
class SectionMetrics:
    similarity_score: float
    pixel_difference: float
    average_color_shift: float
    brightness_shift: float
    edge_density_delta: float
    design_size: dict[str, int]
    website_size: dict[str, int]
    notes: list[str] = field(default_factory=list)


@dataclass
class SectionAudit:
    name: str
    bounds: dict[str, float]
    metrics: SectionMetrics
    findings: list[Finding] = field(default_factory=list)
    qa_notes: list[str] = field(default_factory=list)
    heuristic_summary: str = ""
    raw_model_output: dict[str, Any] | None = None


@dataclass
class AuditSummary:
    total_sections: int
    total_findings: int
    highest_severity: str
    risk_score: int
    release_recommendation: str
    focus_areas: list[str] = field(default_factory=list)
    blockers: list[str] = field(default_factory=list)


@dataclass
class AuditReport:
    project: str
    generated_at: str
    inputs: dict[str, Any]
    summary: AuditSummary
    sections: list[SectionAudit]
    qa_handoff: dict[str, Any]
    artifacts: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
