"""GenAI UI auditor package."""
