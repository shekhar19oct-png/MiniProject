from __future__ import annotations

import math
import struct
import subprocess
import zlib
from dataclasses import dataclass
from pathlib import Path


RGB = tuple[int, int, int]


@dataclass
class ImageData:
    path: Path
    width: int
    height: int
    pixels: list[list[RGB]]


@dataclass
class ImageSection:
    name: str
    start_ratio: float
    end_ratio: float
    width: int
    height: int
    pixels: list[list[RGB]]


def load_image(path: str | Path) -> ImageData:
    image_path = Path(path)
    try:
        return _load_with_pillow(image_path)
    except RuntimeError:
        return _load_png(image_path)


def resolve_design_input(source: str | Path, temp_dir: str | Path) -> Path:
    source_path = Path(source)
    if source_path.suffix.lower() != ".pdf":
        return source_path

    destination = Path(temp_dir) / "design_from_pdf.png"
    destination.parent.mkdir(parents=True, exist_ok=True)
    _convert_pdf_to_png(source_path, destination)
    return destination


def _load_with_pillow(path: Path) -> ImageData:
    try:
        from PIL import Image  # type: ignore
    except ImportError as exc:
        raise RuntimeError("Pillow is not installed.") from exc

    with Image.open(path) as img:
        rgb = img.convert("RGB")
        width, height = rgb.size
        data = list(rgb.getdata())
        rows = [
            [data[(y * width) + x] for x in range(width)]
            for y in range(height)
        ]
    return ImageData(path=path, width=width, height=height, pixels=rows)


def _load_png(path: Path) -> ImageData:
    raw = path.read_bytes()
    signature = b"\x89PNG\r\n\x1a\n"
    if not raw.startswith(signature):
        raise RuntimeError(
            "Only PNG images are supported without Pillow. Install Pillow for JPEG/WebP support."
        )

    width = height = bit_depth = color_type = interlace = None
    idat_chunks: list[bytes] = []
    offset = len(signature)

    while offset < len(raw):
        chunk_length = struct.unpack(">I", raw[offset : offset + 4])[0]
        offset += 4
        chunk_type = raw[offset : offset + 4]
        offset += 4
        chunk_data = raw[offset : offset + chunk_length]
        offset += chunk_length + 4

        if chunk_type == b"IHDR":
            width, height, bit_depth, color_type, _, _, interlace = struct.unpack(
                ">IIBBBBB", chunk_data
            )
        elif chunk_type == b"IDAT":
            idat_chunks.append(chunk_data)
        elif chunk_type == b"IEND":
            break

    if width is None or height is None or bit_depth is None or color_type is None:
        raise RuntimeError("Malformed PNG: missing IHDR.")

    if bit_depth != 8:
        raise RuntimeError("This lightweight decoder supports only 8-bit PNGs.")
    if interlace != 0:
        raise RuntimeError("Interlaced PNGs require Pillow.")

    channel_count = {
        0: 1,
        2: 3,
        4: 2,
        6: 4,
    }.get(color_type)
    if channel_count is None:
        raise RuntimeError(
            "Unsupported PNG color type for lightweight mode. Install Pillow."
        )

    compressed = b"".join(idat_chunks)
    decompressed = zlib.decompress(compressed)
    stride = width * channel_count
    pixels: list[list[RGB]] = []
    cursor = 0
    previous = bytearray(stride)

    for _ in range(height):
        filter_type = decompressed[cursor]
        cursor += 1
        scanline = bytearray(decompressed[cursor : cursor + stride])
        cursor += stride
        recon = _defilter_row(filter_type, scanline, previous, channel_count)
        pixels.append(_scanline_to_rgb(recon, color_type))
        previous = recon

    return ImageData(path=path, width=width, height=height, pixels=pixels)


def _defilter_row(
    filter_type: int, row: bytearray, previous: bytearray, bytes_per_pixel: int
) -> bytearray:
    result = bytearray(len(row))
    for index, value in enumerate(row):
        left = result[index - bytes_per_pixel] if index >= bytes_per_pixel else 0
        up = previous[index] if previous else 0
        up_left = (
            previous[index - bytes_per_pixel]
            if previous and index >= bytes_per_pixel
            else 0
        )

        if filter_type == 0:
            recon = value
        elif filter_type == 1:
            recon = (value + left) & 0xFF
        elif filter_type == 2:
            recon = (value + up) & 0xFF
        elif filter_type == 3:
            recon = (value + ((left + up) // 2)) & 0xFF
        elif filter_type == 4:
            recon = (value + _paeth_predictor(left, up, up_left)) & 0xFF
        else:
            raise RuntimeError(f"Unsupported PNG filter type: {filter_type}")

        result[index] = recon
    return result


def _paeth_predictor(left: int, up: int, up_left: int) -> int:
    estimate = left + up - up_left
    left_distance = abs(estimate - left)
    up_distance = abs(estimate - up)
    up_left_distance = abs(estimate - up_left)

    if left_distance <= up_distance and left_distance <= up_left_distance:
        return left
    if up_distance <= up_left_distance:
        return up
    return up_left


def _scanline_to_rgb(scanline: bytearray, color_type: int) -> list[RGB]:
    row: list[RGB] = []

    if color_type == 0:
        for value in scanline:
            row.append((value, value, value))
        return row

    if color_type == 2:
        for index in range(0, len(scanline), 3):
            row.append((scanline[index], scanline[index + 1], scanline[index + 2]))
        return row

    if color_type == 4:
        for index in range(0, len(scanline), 2):
            gray = scanline[index]
            alpha = scanline[index + 1]
            row.append(_flatten_alpha((gray, gray, gray), alpha))
        return row

    if color_type == 6:
        for index in range(0, len(scanline), 4):
            rgb = (scanline[index], scanline[index + 1], scanline[index + 2])
            alpha = scanline[index + 3]
            row.append(_flatten_alpha(rgb, alpha))
        return row

    raise RuntimeError("Unsupported PNG color type.")


def _flatten_alpha(rgb: RGB, alpha: int) -> RGB:
    if alpha >= 255:
        return rgb
    background = 255
    blended = []
    for channel in rgb:
        blended.append(int((channel * alpha + background * (255 - alpha)) / 255))
    return (blended[0], blended[1], blended[2])


def get_section(image: ImageData, name: str, start_ratio: float, end_ratio: float) -> ImageSection:
    start = max(0, min(image.height - 1, int(image.height * start_ratio)))
    end = max(start + 1, min(image.height, int(image.height * end_ratio)))
    return ImageSection(
        name=name,
        start_ratio=start_ratio,
        end_ratio=end_ratio,
        width=image.width,
        height=end - start,
        pixels=image.pixels[start:end],
    )


def compare_sections(design: ImageSection, website: ImageSection) -> dict[str, float | dict[str, int] | list[str]]:
    design_grid = _sample_grid(design)
    website_grid = _sample_grid(website)

    pixel_difference = _average_grid_difference(design_grid, website_grid)
    average_color_shift = _normalized_color_distance(
        _average_color_from_grid(design_grid),
        _average_color_from_grid(website_grid),
    )
    brightness_shift = abs(
        _average_brightness(design_grid) - _average_brightness(website_grid)
    ) / 255.0
    edge_density_delta = abs(
        _edge_density(design_grid) - _edge_density(website_grid)
    )

    similarity_score = max(
        0.0,
        1.0
        - (
            (pixel_difference * 0.55)
            + (average_color_shift * 0.2)
            + (brightness_shift * 0.1)
            + (edge_density_delta * 0.1)
        ),
    )

    notes: list[str] = []
    if pixel_difference > 0.3:
        notes.append("Visual variance is large enough to justify a focused QA review.")
    if edge_density_delta > 0.15:
        notes.append("Element density drift suggests spacing or missing-content changes.")

    return {
        "similarity_score": round(similarity_score, 3),
        "pixel_difference": round(pixel_difference, 3),
        "average_color_shift": round(average_color_shift, 3),
        "brightness_shift": round(brightness_shift, 3),
        "edge_density_delta": round(edge_density_delta, 3),
        "design_size": {"width": design.width, "height": design.height},
        "website_size": {"width": website.width, "height": website.height},
        "notes": notes,
    }


def image_metadata(path: str | Path) -> dict[str, int | str]:
    image = load_image(path)
    return {
        "path": str(Path(path).resolve()),
        "width": image.width,
        "height": image.height,
    }


def maybe_capture_with_sips(source: Path, destination: Path, max_width: int = 1400) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    command = [
        "sips",
        "--resampleWidth",
        str(max_width),
        str(source),
        "--out",
        str(destination),
    ]
    subprocess.run(command, check=True, capture_output=True)
    return destination


def _convert_pdf_to_png(source: Path, destination: Path) -> None:
    command = [
        "sips",
        "-s",
        "format",
        "png",
        str(source),
        "--out",
        str(destination),
    ]
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        raise RuntimeError(
            f"Failed to convert design PDF to PNG via sips: {stderr or 'unknown error'}"
        )


def _sample_grid(section: ImageSection, columns: int = 24, rows: int = 24) -> list[list[RGB]]:
    grid: list[list[RGB]] = []
    height = max(1, section.height)
    width = max(1, section.width)

    for row_index in range(rows):
        y = min(height - 1, int(((row_index + 0.5) / rows) * height))
        grid_row: list[RGB] = []
        for column_index in range(columns):
            x = min(width - 1, int(((column_index + 0.5) / columns) * width))
            grid_row.append(section.pixels[y][x])
        grid.append(grid_row)
    return grid


def _average_grid_difference(a: list[list[RGB]], b: list[list[RGB]]) -> float:
    total = 0.0
    count = 0
    for row_a, row_b in zip(a, b):
        for pixel_a, pixel_b in zip(row_a, row_b):
            total += (
                abs(pixel_a[0] - pixel_b[0])
                + abs(pixel_a[1] - pixel_b[1])
                + abs(pixel_a[2] - pixel_b[2])
            ) / (255 * 3)
            count += 1
    return total / max(count, 1)


def _average_color_from_grid(grid: list[list[RGB]]) -> RGB:
    red = green = blue = count = 0
    for row in grid:
        for pixel in row:
            red += pixel[0]
            green += pixel[1]
            blue += pixel[2]
            count += 1
    if count == 0:
        return (0, 0, 0)
    return (red // count, green // count, blue // count)


def _normalized_color_distance(a: RGB, b: RGB) -> float:
    distance = math.sqrt(
        ((a[0] - b[0]) ** 2) + ((a[1] - b[1]) ** 2) + ((a[2] - b[2]) ** 2)
    )
    return distance / math.sqrt(255**2 * 3)


def _average_brightness(grid: list[list[RGB]]) -> float:
    values = []
    for row in grid:
        for red, green, blue in row:
            values.append((red + green + blue) / 3)
    return sum(values) / max(len(values), 1)


def _edge_density(grid: list[list[RGB]]) -> float:
    threshold = 36
    edges = 0
    comparisons = 0

    for row_index, row in enumerate(grid):
        for column_index, pixel in enumerate(row):
            if column_index + 1 < len(row):
                if _pixel_delta(pixel, row[column_index + 1]) > threshold:
                    edges += 1
                comparisons += 1
            if row_index + 1 < len(grid):
                if _pixel_delta(pixel, grid[row_index + 1][column_index]) > threshold:
                    edges += 1
                comparisons += 1
    return edges / max(comparisons, 1)


def _pixel_delta(a: RGB, b: RGB) -> float:
    return (
        abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2])
    ) / 3
