from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from utils.capture import capture_website
from utils.config import AuditConfig
from utils.image_tools import (
    compare_sections,
    get_section,
    image_metadata,
    load_image,
    resolve_design_input,
)
from utils.llm_engine import compare_section_with_llm, llm_runtime_status
from utils.models import (
    AuditReport,
    AuditSummary,
    BugTicket,
    Finding,
    SectionAudit,
    SectionMetrics,
    SEVERITY_RANK,
)
from utils.reporter import generate


def run_audit(config: AuditConfig) -> AuditReport:
    website_path = _resolve_website_image(config)
    design_path = resolve_design_input(config.design_image, config.temp_dir)

    design = load_image(design_path)
    website = load_image(website_path)

    section_audits: list[SectionAudit] = []
    llm_status = llm_runtime_status(config)
    if config.require_llm and not llm_status["enabled"]:
        raise RuntimeError(
            f"LLM is required but not available: {llm_status['reason']}. "
            "Fix GEMINI_API_KEY/dependencies, or run without --require-llm."
        )

    for index, (name, start_ratio, end_ratio) in enumerate(config.section_definitions, start=1):
        design_section = get_section(design, name, start_ratio, end_ratio)
        website_section = get_section(website, name, start_ratio, end_ratio)
        metrics = SectionMetrics(**compare_sections(design_section, website_section))

        findings: list[Finding] = []
        qa_notes = _build_section_notes(name, metrics, llm_status)
        raw_model_output = None

        if llm_status["enabled"]:
            raw_model_output = compare_section_with_llm(
                config=config,
                section_name=name,
                section_bounds={"start_ratio": start_ratio, "end_ratio": end_ratio},
                design_path=design_path,
                website_path=website_path,
                metrics=asdict(metrics),
            )
            findings.extend(_llm_findings_to_models(raw_model_output, name, index))
            qa_notes.extend(raw_model_output.get("qa_notes", []))
        else:
            findings = _build_heuristic_findings(name, metrics, index)

        findings = _rank_findings(findings, config.max_findings_per_section)
        section_audits.append(
            SectionAudit(
                name=name,
                bounds={"start_ratio": start_ratio, "end_ratio": end_ratio},
                metrics=metrics,
                findings=findings,
                qa_notes=_dedupe_preserve_order(qa_notes),
                heuristic_summary=_section_summary(name, metrics),
                raw_model_output=raw_model_output,
            )
        )

    report = AuditReport(
        project=config.project_name,
        generated_at=datetime.now(timezone.utc).isoformat(),
        inputs={
            "design_image": image_metadata(design_path),
            "website_image": image_metadata(website_path),
            "website_url": config.website_url,
            "target_name": config.target_name,
            "llm_status": llm_status,
            "design_source": str(config.design_image),
        },
        summary=_summarize(section_audits),
        sections=section_audits,
        qa_handoff=_build_qa_handoff(section_audits),
    )

    report.artifacts = generate(report, config.output_dir)
    return report


def _resolve_website_image(config: AuditConfig) -> Path:
    if config.capture_enabled:
        destination = config.temp_dir / "captured_website.png"
        capture_website(config.website_url or "", destination)
        return destination

    if config.website_image is None:
        destination = config.temp_dir / "captured_website.png"
        capture_website(config.website_url or "", destination)
        return destination

    return config.website_image


def _build_heuristic_findings(
    section_name: str, metrics: SectionMetrics, index: int
) -> list[Finding]:
    findings: list[Finding] = []
    prefix = section_name.upper().replace(" ", "_")

    if metrics.pixel_difference >= 0.38:
        findings.append(
            _make_finding(
                finding_id=f"{prefix}-{index:02d}-VISUAL",
                title=f"{section_name.title()} section diverges heavily from the reference",
                category="visual-regression",
                severity="high",
                confidence=0.85,
                impact="The rendered section likely contains visible layout or content regressions that should block sign-off until reviewed.",
                evidence=[
                    f"Pixel difference score is {metrics.pixel_difference:.3f}.",
                    f"Similarity score dropped to {metrics.similarity_score:.3f}.",
                ],
                suggestions=[
                    "Review spacing, order, and missing components against the approved design.",
                    "Validate responsive rules and component overrides for this page section.",
                ],
                section_name=section_name,
                source="heuristic",
            )
        )
    elif metrics.pixel_difference >= 0.24:
        findings.append(
            _make_finding(
                finding_id=f"{prefix}-{index:02d}-DRIFT",
                title=f"{section_name.title()} section shows moderate visual drift",
                category="layout-drift",
                severity="medium",
                confidence=0.73,
                impact="The UI may still function, but the regression is visible enough that manual verification is warranted.",
                evidence=[
                    f"Pixel difference score is {metrics.pixel_difference:.3f}.",
                    f"Edge density delta is {metrics.edge_density_delta:.3f}.",
                ],
                suggestions=[
                    "Inspect content density, alignment, and vertical rhythm.",
                    "Confirm that the intended components render in the correct order.",
                ],
                section_name=section_name,
                source="heuristic",
            )
        )

    if metrics.average_color_shift >= 0.16 or metrics.brightness_shift >= 0.16:
        findings.append(
            _make_finding(
                finding_id=f"{prefix}-{index:02d}-STYLE",
                title=f"{section_name.title()} section has noticeable style or contrast drift",
                category="styling",
                severity="medium" if metrics.brightness_shift < 0.24 else "high",
                confidence=0.69,
                impact="Branding consistency and readability may be affected, which can also hide accessibility regressions.",
                evidence=[
                    f"Average color shift is {metrics.average_color_shift:.3f}.",
                    f"Brightness shift is {metrics.brightness_shift:.3f}.",
                ],
                suggestions=[
                    "Check theme variables, font color inheritance, and background overlays.",
                    "Run a focused accessibility contrast review for this section.",
                ],
                section_name=section_name,
                source="heuristic",
            )
        )

    if metrics.edge_density_delta >= 0.15:
        findings.append(
            _make_finding(
                finding_id=f"{prefix}-{index:02d}-CONTENT",
                title=f"{section_name.title()} content density differs from the design",
                category="content-structure",
                severity="medium",
                confidence=0.66,
                impact="The implemented screen may have missing cards, extra labels, or spacing shifts that alter the user journey.",
                evidence=[
                    f"Edge density delta is {metrics.edge_density_delta:.3f}.",
                ],
                suggestions=[
                    "Confirm whether hidden states, conditional banners, or skeleton loaders are changing the structure.",
                    "Verify empty, loading, and populated states for this region.",
                ],
                section_name=section_name,
                source="heuristic",
            )
        )

    if not findings:
        findings.append(
            _make_finding(
                finding_id=f"{prefix}-{index:02d}-SMOKE",
                title=f"{section_name.title()} section passed visual smoke heuristics",
                category="smoke-check",
                severity="low",
                confidence=0.6,
                impact="No strong regression signal was detected locally, though exploratory QA can still uncover behavior issues.",
                evidence=[
                    f"Similarity score is {metrics.similarity_score:.3f}.",
                ],
                suggestions=[
                    "Spot-check the section on target breakpoints and browsers.",
                ],
                section_name=section_name,
                source="heuristic",
            )
        )

    return findings


def _make_finding(
    finding_id: str,
    title: str,
    category: str,
    severity: str,
    confidence: float,
    impact: str,
    evidence: list[str],
    suggestions: list[str],
    section_name: str,
    source: str,
) -> Finding:
    reproduction_steps = [
        "Open the audited page or screen in the test environment.",
        f"Navigate to the {section_name} section.",
        "Compare the rendered UI with the approved design reference.",
        "Capture a screenshot if the mismatch is reproducible.",
    ]
    acceptance_checks = [
        f"{section_name.title()} matches the expected layout and visual hierarchy.",
        "Text, spacing, and styling align with the approved design system.",
        "The regression is covered by at least one repeatable test scenario.",
    ]
    return Finding(
        finding_id=finding_id,
        title=title,
        category=category,
        severity=severity,
        confidence=round(confidence, 2),
        impact=impact,
        evidence=evidence,
        suggestions=suggestions,
        test_ideas=[
            f"Perform a screenshot comparison for the {section_name} section across supported breakpoints.",
            f"Verify loading, empty, and error states impacting the {section_name} region.",
        ],
        automation_ideas=[
            f"Add a visual regression snapshot targeting the {section_name} section.",
            "Include DOM assertions for visible labels and expected component count.",
        ],
        bug_ticket=BugTicket(
            title=title,
            severity=severity,
            reproduction_steps=reproduction_steps,
            acceptance_checks=acceptance_checks,
        ),
        source=source,
    )


def _build_section_notes(
    section_name: str, metrics: SectionMetrics, llm_status: dict[str, str | bool]
) -> list[str]:
    notes = [f"Local similarity score for {section_name} is {metrics.similarity_score:.3f}."]
    notes.extend(metrics.notes)
    if not llm_status["enabled"]:
        notes.append(f"LLM enrichment skipped: {llm_status['reason']}")
    return notes


def _llm_findings_to_models(
    payload: dict[str, object] | None, section_name: str, index: int
) -> list[Finding]:
    if not payload:
        return []

    items = payload.get("findings", [])
    if not isinstance(items, list):
        return []

    models: list[Finding] = []
    for item_index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            continue
        title = str(item.get("title", "")).strip() or f"{section_name.title()} LLM finding"
        severity = str(item.get("severity", "medium")).lower()
        evidence = _list_of_strings(item.get("evidence"))
        suggestions = _list_of_strings(item.get("suggestions"))
        test_ideas = _list_of_strings(item.get("test_ideas"))
        automation_ideas = _list_of_strings(item.get("automation_ideas"))
        impact = str(item.get("impact", "Potential UI issue requiring manual QA validation."))
        confidence = float(item.get("confidence", 0.65))
        category = str(item.get("category", "llm-observation"))

        models.append(
            Finding(
                finding_id=f"{section_name.upper()}-{index:02d}-LLM-{item_index:02d}",
                title=title,
                category=category,
                severity=severity,
                confidence=round(confidence, 2),
                impact=impact,
                evidence=evidence,
                suggestions=suggestions,
                test_ideas=test_ideas,
                automation_ideas=automation_ideas,
                bug_ticket=BugTicket(
                    title=title,
                    severity=severity,
                    reproduction_steps=_list_of_strings(item.get("reproduction_steps"))
                    or [
                        "Open the same screen in the target environment.",
                        f"Inspect the {section_name} section.",
                        "Compare behavior and visuals against the approved reference.",
                    ],
                    acceptance_checks=_list_of_strings(item.get("acceptance_checks"))
                    or [
                        "The section matches design intent.",
                        "The regression is no longer reproducible.",
                    ],
                ),
                source="llm",
            )
        )
    return models


def _rank_findings(findings: list[Finding], limit: int) -> list[Finding]:
    ranked = sorted(
        findings,
        key=lambda finding: (
            SEVERITY_RANK.get(finding.severity, 0),
            finding.confidence,
        ),
        reverse=True,
    )
    return ranked[:limit]


def _section_summary(section_name: str, metrics: SectionMetrics) -> str:
    if metrics.similarity_score >= 0.85:
        tone = "close to baseline"
    elif metrics.similarity_score >= 0.7:
        tone = "showing moderate drift"
    else:
        tone = "showing strong regression signals"
    return (
        f"{section_name.title()} is {tone}; "
        f"pixel diff={metrics.pixel_difference:.3f}, "
        f"color shift={metrics.average_color_shift:.3f}, "
        f"edge density delta={metrics.edge_density_delta:.3f}."
    )


def _summarize(sections: list[SectionAudit]) -> AuditSummary:
    findings = [finding for section in sections for finding in section.findings]
    highest = "info"
    for finding in findings:
        if SEVERITY_RANK.get(finding.severity, 0) > SEVERITY_RANK.get(highest, 0):
            highest = finding.severity

    weighted = sum((SEVERITY_RANK.get(finding.severity, 0) * 9) for finding in findings)
    risk_score = min(100, weighted + int((1 - _average_similarity(sections)) * 40))

    blockers = [
        finding.title
        for finding in findings
        if finding.severity in {"high", "critical"}
    ]
    focus_areas = _dedupe_preserve_order(
        [f"{section.name}: {section.heuristic_summary}" for section in sections if section.findings]
    )

    if blockers or risk_score >= 75:
        recommendation = "block release pending focused fixes and retest"
    elif risk_score >= 45:
        recommendation = "allow only after targeted QA regression"
    else:
        recommendation = "safe for exploratory QA with no major blockers detected"

    return AuditSummary(
        total_sections=len(sections),
        total_findings=len(findings),
        highest_severity=highest,
        risk_score=risk_score,
        release_recommendation=recommendation,
        focus_areas=focus_areas[:5],
        blockers=blockers[:5],
    )


def _build_qa_handoff(sections: list[SectionAudit]) -> dict[str, object]:
    exploratory_focus: list[str] = []
    regression_suite_additions: list[str] = []
    manual_checks: list[str] = []
    category_heatmap: defaultdict[str, int] = defaultdict(int)

    for section in sections:
        for finding in section.findings:
            exploratory_focus.append(f"{section.name.title()}: {finding.title}")
            regression_suite_additions.extend(finding.automation_ideas)
            manual_checks.extend(finding.test_ideas)
            category_heatmap[finding.category] += 1

    return {
        "exploratory_focus": _dedupe_preserve_order(exploratory_focus)[:8],
        "regression_suite_additions": _dedupe_preserve_order(regression_suite_additions)[:8],
        "manual_checks": _dedupe_preserve_order(manual_checks)[:8],
        "accessibility_checks": [
            "Verify text contrast for visually changed sections.",
            "Check focus order and keyboard reachability if the changed section contains interactive elements.",
            "Validate zoom or responsive readability at common breakpoints.",
        ],
        "release_gate": _release_gate(sections),
        "category_heatmap": dict(sorted(category_heatmap.items())),
    }


def _release_gate(sections: list[SectionAudit]) -> str:
    high_or_critical = [
        finding
        for section in sections
        for finding in section.findings
        if finding.severity in {"high", "critical"}
    ]
    if high_or_critical:
        return "Do not sign off until the high-severity regressions are fixed and retested."

    medium_findings = sum(
        1
        for section in sections
        for finding in section.findings
        if finding.severity == "medium"
    )
    if medium_findings >= 3:
        return "Run targeted regression before sign-off because several medium-severity drifts were detected."

    return "Proceed with exploratory QA and lightweight regression checks."


def _average_similarity(sections: list[SectionAudit]) -> float:
    if not sections:
        return 1.0
    return sum(section.metrics.similarity_score for section in sections) / len(sections)


def _list_of_strings(value: object) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()]


def _dedupe_preserve_order(items: list[str]) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for item in items:
        if item not in seen:
            seen.add(item)
            deduped.append(item)
    return deduped
