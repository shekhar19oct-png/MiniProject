from __future__ import annotations

from pathlib import Path

from utils.image_tools import image_metadata, load_image


def preprocess(path: str | Path):
    return load_image(path)


def describe_image(path: str | Path) -> dict[str, int | str]:
    return image_metadata(path)
