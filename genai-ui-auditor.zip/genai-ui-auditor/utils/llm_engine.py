from __future__ import annotations

import json
import mimetypes
from pathlib import Path
from typing import Any

from utils.config import AuditConfig


def llm_runtime_status(config: AuditConfig) -> dict[str, str | bool]:
    if not config.llm_enabled:
        return {"enabled": False, "reason": "disabled by CLI flag"}
    if not config.api_key:
        return {"enabled": False, "reason": "GEMINI_API_KEY is not set"}
    try:
        from google import genai  # type: ignore # noqa: F401
    except ImportError:
        return {"enabled": False, "reason": "google-genai package is not installed"}
    return {"enabled": True, "reason": "ready"}


def compare_section_with_llm(
    config: AuditConfig,
    section_name: str,
    section_bounds: dict[str, float],
    design_path: str | Path,
    website_path: str | Path,
    metrics: dict[str, Any],
) -> dict[str, Any] | None:
    status = llm_runtime_status(config)
    if not status["enabled"]:
        return None

    from google import genai  # type: ignore
    from google.genai import types  # type: ignore

    client = genai.Client(api_key=config.api_key)
    prompt = _build_prompt(section_name, section_bounds, metrics)
    design_image = _image_part(design_path, types)
    website_image = _image_part(website_path, types)

    try:
        response = client.models.generate_content(
            model=config.model_name,
            contents=[prompt, design_image, website_image],
            config=types.GenerateContentConfig(
                system_instruction=(
                    "You are a senior QA analyst performing UI regression triage. "
                    "Respond with JSON only."
                ),
                response_mime_type="application/json",
                temperature=0.2,
            ),
        )
        payload = _extract_response_text(response)
    except Exception as exc:  # pragma: no cover - network/runtime dependent
        return {
            "qa_notes": [f"LLM request failed: {exc}"],
            "findings": [],
        }

    parsed = _load_json(payload)
    if parsed is None:
        return {
            "qa_notes": ["LLM response was not valid JSON and was ignored."],
            "findings": [],
        }
    return parsed


def _build_prompt(
    section_name: str,
    section_bounds: dict[str, float],
    metrics: dict[str, Any],
) -> str:
    return f"""
Compare the design reference against the implemented UI, focusing on the "{section_name}" section.

Section bounds:
- start_ratio: {section_bounds["start_ratio"]}
- end_ratio: {section_bounds["end_ratio"]}

Local heuristics:
{json.dumps(metrics, indent=2)}

Return JSON with this shape:
{{
  "qa_notes": ["short tester note"],
  "findings": [
    {{
      "title": "brief issue title",
      "category": "layout | styling | content | accessibility | responsiveness | state-handling",
      "severity": "low | medium | high | critical",
      "confidence": 0.0,
      "impact": "why it matters",
      "evidence": ["specific visual evidence"],
      "suggestions": ["developer-facing fix guidance"],
      "test_ideas": ["manual QA check"],
      "automation_ideas": ["automation candidate"],
      "reproduction_steps": ["step"],
      "acceptance_checks": ["check"]
    }}
  ]
}}

Prioritize findings that help a tester triage, reproduce, and regress the issue. If the section looks acceptable, return an empty findings list and note what should still be manually checked.
""".strip()


def _image_part(path: str | Path, types_module: Any) -> Any:
    mime_type = mimetypes.guess_type(str(path))[0] or "image/png"
    return types_module.Part.from_bytes(
        data=Path(path).read_bytes(),
        mime_type=mime_type,
    )


def _extract_response_text(response: Any) -> str:
    text = getattr(response, "text", None)
    if text:
        return text

    candidates = getattr(response, "candidates", None) or []
    pieces: list[str] = []
    for candidate in candidates:
        content = getattr(candidate, "content", None)
        for part in getattr(content, "parts", []) or []:
            part_text = getattr(part, "text", None)
            if part_text:
                pieces.append(part_text)
    return "".join(pieces)


def _load_json(payload: str) -> dict[str, Any] | None:
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        pass

    start = payload.find("{")
    end = payload.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return None

    try:
        return json.loads(payload[start : end + 1])
    except json.JSONDecodeError:
        return None
