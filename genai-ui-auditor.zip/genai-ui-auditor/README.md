# GenAI UI Auditor

GenAI UI Auditor is a tester-first visual audit tool. It compares a design reference against an implemented screen, produces deterministic local heuristics, and then optionally uses a multimodal Gemini model to convert those differences into triage-ready QA findings.

## Why this version is better

- Works in offline heuristic mode for PNG files even if no Python image packages are installed.
- Accepts design input as image or PDF (`.pdf` is auto-converted to PNG internally).
- Produces tester artifacts, not just raw UI comments: risk score, QA handoff notes, bug ticket drafts, regression ideas, and release guidance.
- Removes unsafe patterns from the original prototype such as hardcoded API keys and disabled SSL verification.
- Supports optional live capture with Selenium, but does not require it for local image-based audits.
- Generates JSON, Markdown, and HTML reports for different audiences.

## Tester-focused outputs

- Section-by-section visual drift findings
- Severity and confidence scoring
- Reproduction and acceptance checklist suggestions
- Manual QA ideas and automation candidates
- Release gate recommendation
- Bug ticket markdown files for medium and higher severity issues

## Project structure

- `main.py`: CLI entrypoint
- `utils/auditor.py`: audit orchestration and finding synthesis
- `utils/image_tools.py`: dependency-light image loading and comparison
- `utils/llm_engine.py`: optional Gemini multimodal enrichment
- `utils/reporter.py`: JSON, Markdown, HTML, and bug ticket generation

## Quick start

1. Run offline with the bundled sample images:

```bash
python3 main.py --design images/design.png --website-image images/website.png --disable-llm
```

2. Run with Gemini enrichment after installing dependencies:

```bash
python3 -m pip install -r requirements.txt
cp .env.example .env
# put your real Gemini key inside .env
python3 main.py --design images/design.png --website-image images/website.png
```

If you want the tool to **fail fast** when AI is not actually used (no heuristic fallback), run with `--require-llm`:

```bash
python3 main.py --design images/design.png --website-image images/website.png --require-llm
```

3. Capture a live page with Selenium:

```bash
python3 main.py \
  --design images/design.png \
  --website-url https://example.com \
  --capture
```

4. Compare against a large production website (AI required):

```bash
python3 main.py \
  --design images/design.png \
  --website-url https://www.apple.com \
  --capture \
  --require-llm
```

5. Compare with a design PDF directly:

```bash
python3 main.py \
  --design /absolute/path/to/approved-design.pdf \
  --website-url https://www.apple.com \
  --capture \
  --require-llm
```

## Custom sections

You can tune the vertical slices that the audit uses:

```bash
python3 main.py \
  --design images/design.png \
  --website-image images/website.png \
  --disable-llm \
  --section header:0:0.15 \
  --section hero:0.15:0.5 \
  --section body:0.5:0.9 \
  --section footer:0.9:1
```

## Notes

- `.env` is loaded automatically by `main.py`, so you do not need to export the Gemini key manually each time if it is stored there.
- Use `GEMINI_API_KEY` in `.env` for the Gemini SDK.
- `--design` supports PDF files and converts them automatically using macOS `sips`.
- Offline mode currently supports PNG images without extra packages. Install Pillow if you want JPEG or WebP input support.
- Selenium capture requires a working browser/driver environment.
- The default Gemini model is `gemini-2.5-flash`, chosen because it supports image understanding and JSON responses. Override with `--model` if your account uses a different model.
