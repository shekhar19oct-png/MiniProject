import argparse
from pathlib import Path

from utils.auditor import run_audit
from utils.config import AuditConfig
from utils.env_loader import load_env_file


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="GenAI UI Auditor for designers, testers, and QA leads."
    )
    parser.add_argument(
        "--design",
        default="images/design.png",
        help="Reference design path (image or PDF).",
    )
    parser.add_argument(
        "--website-image",
        default="images/website.png",
        help="Captured UI image path. Use this for offline audits.",
    )
    parser.add_argument(
        "--website-url",
        default="",
        help="Optional live URL to capture with Selenium when no website image is supplied.",
    )
    parser.add_argument(
        "--output-dir",
        default="output",
        help="Directory for generated reports and tickets.",
    )
    parser.add_argument(
        "--project-name",
        default="GenAI UI Auditor",
        help="Friendly name shown in reports.",
    )
    parser.add_argument(
        "--target-name",
        default="Candidate UI",
        help="Friendly label for the audited implementation.",
    )
    parser.add_argument(
        "--model",
        default="gemini-2.5-flash",
        help="Gemini model for optional multimodal analysis.",
    )
    parser.add_argument(
        "--section",
        action="append",
        default=[],
        help="Custom section in the form name:start_ratio:end_ratio. Example: header:0:0.18",
    )
    parser.add_argument(
        "--max-findings-per-section",
        type=int,
        default=4,
        help="Maximum findings preserved per section after ranking.",
    )
    parser.add_argument(
        "--require-llm",
        action="store_true",
        help="Fail the run unless the Gemini/LLM enrichment executes successfully.",
    )
    parser.add_argument(
        "--disable-llm",
        action="store_true",
        help="Skip Gemini analysis and run heuristic-only mode.",
    )
    parser.add_argument(
        "--capture",
        action="store_true",
        help="Capture the website from --website-url even when a website image path is provided.",
    )
    return parser


def build_config(args: argparse.Namespace) -> AuditConfig:
    return AuditConfig.from_inputs(
        design_image=Path(args.design),
        website_image=Path(args.website_image) if args.website_image else None,
        website_url=args.website_url or None,
        output_dir=Path(args.output_dir),
        project_name=args.project_name,
        target_name=args.target_name,
        model_name=args.model,
        llm_enabled=not args.disable_llm,
        require_llm=args.require_llm,
        capture_enabled=args.capture,
        custom_sections=args.section,
        max_findings_per_section=args.max_findings_per_section,
    )


def main() -> None:
    load_env_file()
    args = build_parser().parse_args()
    report = run_audit(build_config(args))

    print("\nFinal QA Summary")
    print(f"- Sections audited: {report.summary.total_sections}")
    print(f"- Findings raised: {report.summary.total_findings}")
    print(f"- Highest severity: {report.summary.highest_severity}")
    print(f"- Release recommendation: {report.summary.release_recommendation}")
    print(f"- Risk score: {report.summary.risk_score}/100")
    print("\nArtifacts")
    for name, path in report.artifacts.items():
        print(f"- {name}: {path}")


if __name__ == "__main__":
    main()
