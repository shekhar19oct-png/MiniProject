"""Capture a full-page screenshot of a live URL using Playwright."""
from playwright.sync_api import sync_playwright


def capture(url, out_path, width=1440, height=900, full_page=True):
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": width, "height": height})
        page.goto(url, wait_until="networkidle", timeout=60000)
        page.screenshot(path=out_path, full_page=full_page)
        browser.close()
    return out_path
