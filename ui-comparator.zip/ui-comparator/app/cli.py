"""CLI: python -m app.cli --url ... --pdf design.pdf --out report.xlsx"""
import argparse
import os
import tempfile

from .capture import capture
from .pdf_utils import pdf_to_images
from .comparator import compare
from .report import build_report


def main():
    ap = argparse.ArgumentParser(description="GenAI UI Comparator")
    ap.add_argument("--url", required=True, help="Live website URL")
    ap.add_argument("--pdf", required=True, help="Design PDF path")
    ap.add_argument("--out", default="ui_comparison_report.xlsx")
    ap.add_argument("--key", default=os.getenv("GEMINI_API_KEY"))
    ap.add_argument("--width", type=int, default=1440)
    ap.add_argument("--height", type=int, default=900)
    a = ap.parse_args()

    if not a.key:
        raise SystemExit("Provide --key or set GEMINI_API_KEY")

    work = tempfile.mkdtemp(prefix="uicmp_")
    print("Converting design PDF...")
    imgs = pdf_to_images(a.pdf, work)
    print(f"  {len(imgs)} page(s)")
    print("Capturing live screenshot...")
    shot = os.path.join(work, "live.png")
    capture(a.url, shot, width=a.width, height=a.height)
    print("Comparing with Gemini...")
    results = compare(a.key, imgs, shot)
    build_report(results, a.out, meta={"Live URL": a.url,
                                       "Viewport": f"{a.width}x{a.height}",
                                       "Design pages": len(imgs)})
    passed = sum(1 for r in results if str(r.get("status", "")).upper() == "PASS")
    print(f"Done: {a.out}  ({passed}/{len(results)} passed)")


if __name__ == "__main__":
    main()
