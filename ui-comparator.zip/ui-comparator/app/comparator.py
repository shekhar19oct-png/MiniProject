"""Gemini-vision UI comparison: design (PDF page images) vs live screenshot."""
import json
import google.generativeai as genai

PROMPT = """You are a meticulous UI QA tester. Compare the DESIGN image(s) (what the
UI designer intended) against the LIVE SCREENSHOT (what the developer built).

Inspect bit by bit. For EVERY checkable property, output one row. Cover at minimum:
buttons (size, color, border-radius, text, padding), text content (exact wording),
font family, font size, font weight, text color, background colors, image presence
and size, spacing/margins/padding, alignment of every major element, layout order,
icons, and overall responsiveness of placement.

Return ONLY valid JSON (no markdown, no backticks) as an array of objects:
[
  {
    "element": "Primary CTA button",
    "check": "Button size",            // very short: what was compared
    "expected": "240x48px rounded",     // from design
    "actual": "200x44px rounded",       // from live
    "status": "FAIL",                   // PASS or FAIL
    "notes": "Width 40px narrower"      // very short reason, empty if PASS
  }
]
Be exhaustive but each field terse. status must be exactly "PASS" or "FAIL"."""


def _img_part(path, mime):
    with open(path, "rb") as f:
        return {"mime_type": mime, "data": f.read()}


def compare(api_key, design_image_paths, live_screenshot_path):
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel("gemini-2.0-flash")

    parts = [PROMPT, "\n--- DESIGN (intended) ---"]
    for p in design_image_paths:
        parts.append(_img_part(p, "image/png"))
    parts += ["\n--- LIVE SCREENSHOT (built) ---", _img_part(live_screenshot_path, "image/png")]

    resp = model.generate_content(parts, generation_config={"temperature": 0})
    text = resp.text.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()
    return json.loads(text)
