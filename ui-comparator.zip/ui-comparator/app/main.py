"""FastAPI service: upload design PDF + live URL -> Excel comparison report."""
import os
import tempfile
import uuid

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse

from .capture import capture
from .pdf_utils import pdf_to_images
from .comparator import compare
from .report import build_report

app = FastAPI(title="GenAI UI Comparator")

GEMINI_KEY = os.getenv("GEMINI_API_KEY", "")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/compare")
def compare_ui(
    url: str = Form(...),
    design_pdf: UploadFile = File(...),
    gemini_api_key: str = Form(None),
    width: int = Form(1440),
    height: int = Form(900),
):
    api_key = gemini_api_key or GEMINI_KEY
    if not api_key:
        raise HTTPException(400, "Gemini API key required (form field or GEMINI_API_KEY env).")

    work = tempfile.mkdtemp(prefix="uicmp_")
    pdf_path = os.path.join(work, "design.pdf")
    with open(pdf_path, "wb") as f:
        f.write(design_pdf.file.read())

    try:
        design_imgs = pdf_to_images(pdf_path, work)
        shot = os.path.join(work, "live.png")
        capture(url, shot, width=width, height=height)
        results = compare(api_key, design_imgs, shot)
    except Exception as e:
        raise HTTPException(500, f"Comparison failed: {e}")

    out = os.path.join(work, f"ui_comparison_{uuid.uuid4().hex[:8]}.xlsx")
    build_report(results, out, meta={"Live URL": url, "Viewport": f"{width}x{height}",
                                     "Design pages": len(design_imgs)})
    return FileResponse(out, filename="ui_comparison_report.xlsx",
                        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
