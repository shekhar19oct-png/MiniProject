"""Write comparison results to a formatted Excel report."""
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

HEAD_FILL = PatternFill("solid", fgColor="1F4E78")
PASS_FILL = PatternFill("solid", fgColor="C6EFCE")
FAIL_FILL = PatternFill("solid", fgColor="FFC7CE")
PASS_FONT = Font(name="Arial", color="006100")
FAIL_FONT = Font(name="Arial", color="9C0006", bold=True)
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

COLS = [("element", "Element", 28), ("check", "What Was Checked", 24),
        ("expected", "Expected (Design)", 30), ("actual", "Actual (Live)", 30),
        ("status", "Result", 12), ("notes", "Notes", 36)]


def build_report(results, out_path, meta=None):
    wb = Workbook()
    ws = wb.active
    ws.title = "UI Comparison"

    row = 1
    if meta:
        ws.cell(row, 1, "UI Comparison Report").font = Font(name="Arial", bold=True, size=14)
        row += 1
        for k, v in meta.items():
            ws.cell(row, 1, k).font = Font(name="Arial", bold=True)
            ws.cell(row, 2, str(v)).font = Font(name="Arial")
            row += 1
        row += 1

    header_row = row
    for c, (_, label, width) in enumerate(COLS, 1):
        cell = ws.cell(header_row, c, label)
        cell.font = Font(name="Arial", bold=True, color="FFFFFF")
        cell.fill = HEAD_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = BORDER
        ws.column_dimensions[cell.column_letter].width = width
    ws.freeze_panes = ws.cell(header_row + 1, 1)

    for r in results:
        row += 1
        status = str(r.get("status", "")).upper()
        for c, (key, _, _) in enumerate(COLS, 1):
            cell = ws.cell(row, c, r.get(key, ""))
            cell.border = BORDER
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            cell.font = Font(name="Arial")
            if key == "status":
                cell.alignment = Alignment(horizontal="center", vertical="center")
                if status == "PASS":
                    cell.fill, cell.font = PASS_FILL, PASS_FONT
                elif status == "FAIL":
                    cell.fill, cell.font = FAIL_FILL, FAIL_FONT

    total = len(results)
    passed = sum(1 for r in results if str(r.get("status", "")).upper() == "PASS")
    row += 2
    ws.cell(row, 1, "Summary").font = Font(name="Arial", bold=True, size=12)
    ws.cell(row + 1, 1, "Total checks").font = Font(name="Arial", bold=True)
    ws.cell(row + 1, 2, total)
    ws.cell(row + 2, 1, "Passed").font = Font(name="Arial", bold=True)
    ws.cell(row + 2, 2, passed)
    ws.cell(row + 3, 1, "Failed").font = Font(name="Arial", bold=True)
    ws.cell(row + 3, 2, total - passed)
    ws.cell(row + 4, 1, "Pass rate").font = Font(name="Arial", bold=True)
    pr = ws.cell(row + 4, 2, (passed / total) if total else 0)
    pr.number_format = "0.0%"

    wb.save(out_path)
    return out_path
