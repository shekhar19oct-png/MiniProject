"""Convert a design PDF into per-page PNG images for Gemini input."""
import fitz  # PyMuPDF


def pdf_to_images(pdf_path, out_dir, zoom=2.0):
    doc = fitz.open(pdf_path)
    paths = []
    mat = fitz.Matrix(zoom, zoom)
    for i, page in enumerate(doc):
        pix = page.get_pixmap(matrix=mat)
        out = f"{out_dir}/design_page_{i+1}.png"
        pix.save(out)
        paths.append(out)
    doc.close()
    return paths
