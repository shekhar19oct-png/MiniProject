# GenAI UI Comparator

Compares a **design PDF** (what the UI designer intended) against a **live website**
(what the developer built), using **Gemini vision** as the judge. Outputs an **Excel
report** with one row per check — what was compared, expected vs actual, and PASS/FAIL.

## How it works
1. Design PDF → per-page PNGs (PyMuPDF)
2. Live URL → full-page screenshot (Playwright/Chromium)
3. Both images → Gemini, which inspects bit by bit (button size, content, font size,
   color, alignment, spacing, etc.) and returns structured JSON
4. JSON → formatted `.xlsx` with green PASS / red FAIL rows and a summary

## Setup
```bash
pip install -r requirements.txt
playwright install chromium
export GEMINI_API_KEY=your_key   # or pass per-request
```

## Run as API
```bash
uvicorn app.main:app --reload
```
POST `/compare` (multipart form):
- `url` — live website URL
- `design_pdf` — the design file
- `gemini_api_key` — optional if env var set
- `width`, `height` — optional viewport (default 1440x900)

Returns the Excel report as a download.

## Run as CLI
```bash
python -m app.cli --url https://yoursite.com --pdf design.pdf --out report.xlsx
```

## Report columns
Element | What Was Checked | Expected (Design) | Actual (Live) | Result | Notes

Plus a summary block: total checks, passed, failed, pass rate.

## Notes
- Gemini judges visually; for stricter pixel/DOM checks you can later add a
  pixel-diff or computed-style layer.
- `gemini-2.0-flash` is used by default (fast, multimodal). Swap the model name in
  `app/comparator.py` if needed.
