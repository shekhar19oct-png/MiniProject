package com.coursera.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EnterprisePage {

    private final WebDriver driver;
    private final WebDriverWait wait;
    private final JavascriptExecutor js;

    public EnterprisePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }

    // LOCATORS
    @FindBy(linkText = "For Enterprise")
    WebElement enterpriseLinkText;

    @FindBy(xpath = "//input[@id='FirstName'] | //input[@name='firstname']")
    WebElement firstName;

    @FindBy(xpath = "//input[@id='LastName'] | //input[@name='lastname']")
    WebElement lastName;

    @FindBy(xpath = "//input[@id='Email'] | //input[@type='email']")
    WebElement email;

    @FindBy(xpath = "//input[@id='Phone'] | //input[@type='tel']")
    WebElement phone;

    @FindBy(xpath = "//select[@id='rentalField9'] | //select[contains(@name,'Organization')]")
    WebElement organization;

    @FindBy(xpath = "//input[@id='Title'] | //input[@name='Title']")
    WebElement jobTitle;

//    @FindBy(xpath = "//input[@id='Company' or @name='Company']")
//    WebElement company;
//
//    @FindBy(xpath = "//select[@id='Employee_Range__c' or contains(@name,'Employee_Range')]")
//    WebElement employeeRange;


    @FindBy(xpath = "//select[@id='Self_Reported_Needs__c'] | //select[contains(@name,'Self_Reported_Needs')]")
    WebElement needs;

    @FindBy(xpath = "//select[@id='Country'] | //select[@name='Country']")
    WebElement country;

    // NEW: State field locator - supports multiple possible selectors
    @FindBy(xpath = "//select[@id='State'] | //select[@name='State'] | //select[contains(@id,'State')] | //select[contains(@name,'state')]")
    WebElement state;

    @FindBy(xpath = "//button[contains(text(),'Submit')] | //input[@type='submit']")
    WebElement submitButton;

    @FindBy(xpath = "//div[contains(@class,'mktoError')]")
    WebElement errorMsg;

    @FindBy(xpath = "//h1[contains(text(),'Thank')] | //div[contains(text(),'Thank you')]")
    WebElement successMsg;


    // ACTIONS
    public void scrollToEnterprise() throws InterruptedException {
        for (int i = 0; i < 3; i++) {
            js.executeScript("window.scrollBy(0, 800);");
            Thread.sleep(800);
        }
        js.executeScript("arguments[0].scrollIntoView(true);", enterpriseLinkText);
        Thread.sleep(1000);
    }

    public void navigateToEnterprise() {
        wait.until(ExpectedConditions.elementToBeClickable(enterpriseLinkText)).click();
    }

    public void enterFirstName(String firstNameText) {
        try {
            wait.until(ExpectedConditions.visibilityOf(firstName));
            firstName.clear();
            firstName.sendKeys(firstNameText);
        } catch (Exception e) {
            js.executeScript("arguments[0].value = arguments[1];", firstName, firstNameText);
        }
    }

    public void enterLastName(String lastNameText) {
        try {
            wait.until(ExpectedConditions.visibilityOf(lastName));
            lastName.clear();
            lastName.sendKeys(lastNameText);
        } catch (Exception e) {
            js.executeScript("arguments[0].value = arguments[1];", lastName, lastNameText);
        }
    }

    public void enterEmail(String emailText) {
        try {
            wait.until(ExpectedConditions.visibilityOf(email));
            email.clear();
            email.sendKeys(emailText);
        } catch (Exception e) {
            js.executeScript("arguments[0].value = arguments[1];", email, emailText);
        }
    }

    public void enterPhone(String phoneText) {
        try {
            wait.until(ExpectedConditions.visibilityOf(phone));
            phone.clear();
            phone.sendKeys(phoneText);
        } catch (Exception e) {
            js.executeScript("arguments[0].value = arguments[1];", phone, phoneText);
        }
    }

    public void selectOrganization(String org) {
        try {
            wait.until(ExpectedConditions.visibilityOf(organization));
            new Select(organization).selectByVisibleText(org);
        } catch (Exception e) {
            System.out.println("Selecting organization: " + e.getMessage());
        }
    }

    public void enterJobTitle(String jobTitleText) {
        try {
            wait.until(ExpectedConditions.visibilityOf(jobTitle));
            jobTitle.clear();
            jobTitle.sendKeys(jobTitleText);
        } catch (Exception e) {
            js.executeScript("arguments[0].value = arguments[1];", jobTitle, jobTitleText);
        }
    }
//    public void enterCompany(String company) {
//        wait.until(ExpectedConditions.visibilityOf(this.company));
//        this.company.clear();
//        this.company.sendKeys(company);
//    }

//    public void selectEmployeeRange(String range) {
//        wait.until(ExpectedConditions.visibilityOf(employeeRange));
//        new Select(employeeRange).selectByVisibleText(range);
//    }



    public void selectNeeds(String needText) {
        try {
            wait.until(ExpectedConditions.visibilityOf(needs));
            new Select(needs).selectByVisibleText(needText);
            System.out.println("Selected needs: " + needText);
        } catch (Exception e) {
            System.out.println("Error selecting needs: " + e.getMessage());
        }
    }

    public void selectCountry(String countryText) {
        try {
            wait.until(ExpectedConditions.visibilityOf(country));
            new Select(country).selectByVisibleText(countryText);
            System.out.println("Selected country: " + countryText);

            // Wait for state field to appear after country selection (India)
            if (countryText.equalsIgnoreCase("India")) {
                waitForStateFieldAndSelect();
            }
        } catch (Exception e) {
            System.out.println("Error selecting country: " + e.getMessage());
        }
    }

    // NEW METHOD: Wait for state field and select "Madhya Pradesh"
    public void waitForStateFieldAndSelect() {
        try {
            System.out.println("Waiting for State field to appear...");
            Thread.sleep(2000); // Short wait for dynamic field to load

            // Try multiple strategies to find and select state
            WebElement stateElement = null;

            // Strategy 1: Wait for the state select element
            try {
                stateElement = wait.until(ExpectedConditions.visibilityOf(state));
            } catch (Exception e1) {
                // Strategy 2: Try with more specific xpath
                try {
                    stateElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//select[contains(@id,'State') or contains(@name,'State')]")
                    ));
                } catch (Exception e2) {
                    // Strategy 3: Try with any select element that contains 'state' in id/name
                    stateElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
                            By.xpath("//select[contains(translate(@id, 'state', 'STATE'), 'STATE') or contains(translate(@name, 'state', 'STATE'), 'STATE')]")
                    ));
                }
            }

            if (stateElement != null && stateElement.isDisplayed()) {
                System.out.println("State field found! Selecting Madhya Pradesh...");
                Select stateSelect = new Select(stateElement);
                stateSelect.selectByVisibleText("Madhya Pradesh");
                System.out.println("Selected State: Madhya Pradesh");
                Thread.sleep(1000); // Small wait after selection
            } else {
                System.out.println("State field not found - checking if it's required...");
                // Optional: Log all selects on page for debugging
                List<WebElement> allSelects = driver.findElements(By.tagName("select"));
                System.out.println("Total select elements on page: " + allSelects.size());
                for (WebElement sel : allSelects) {
                    System.out.println("Select - id: " + sel.getAttribute("id") + ", name: " + sel.getAttribute("name"));
                }
            }
        } catch (Exception e) {
            System.out.println("State field handling failed (may not be required): " + e.getMessage());
        }
    }

    public void fillForm(String firstName, String lastName, String email, String phone,
                         String organisation, String jobTitle, String needsValue, String countryValue) {
        System.out.println("Filling form...");
        enterFirstName(firstName);
        enterLastName(lastName);
        enterEmail(email);
        enterPhone(phone);
        selectOrganization(organisation);
        enterJobTitle(jobTitle);
//        selectEmployeeRange(employeeRangeValue);

//        enterCompany(companyName);
        selectNeeds(needsValue);
        selectCountry(countryValue);  // State selection is handled inside selectCountry() for India
        System.out.println("Form filled successfully!");
    }

    public void clickSubmit() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(submitButton));
            js.executeScript("arguments[0].scrollIntoView(true);", submitButton);
            js.executeScript("arguments[0].click();", submitButton);
            System.out.println("Submit button clicked!");
        } catch (Exception e) {
            System.out.println("Error clicking submit: " + e.getMessage());
        }
    }

    public boolean isErrorMsgDisplayed() {
        try {
            wait.until(ExpectedConditions.visibilityOf(errorMsg));
            return errorMsg.isDisplayed();
        } catch (TimeoutException e) {
            return false;
        }
    }

    public String getErrorMessage() {
        try {
            return errorMsg.getText();
        } catch (Exception e) {
            return "No error";
        }
    }

    public void debugPrintAllFields() {
        System.out.println("\n========== ALL FORM FIELDS ==========");
        List<WebElement> inputs = driver.findElements(By.xpath("//input | //select | //textarea"));
        for (WebElement el : inputs) {
            try {
                String id = el.getAttribute("id");
                String name = el.getAttribute("name");
                String placeholder = el.getAttribute("placeholder");
                String type = el.getTagName();
                System.out.println(type + " - id: " + id + ", name: " + name + ", placeholder: " + placeholder);
            } catch (Exception e) {}
        }
        System.out.println("=====================================\n");
    }
}