package com.coursera.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.coursera.utils.Course;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class SearchedResultsPage {

    private final WebDriver driver;
    private final WebDriverWait wait;
    private final JavascriptExecutor js;
    private static List<String> languages;
    private static List<String> levels;


    // CONSTRUCTOR
    public SearchedResultsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(3));
        this.js = (JavascriptExecutor) driver;
        PageFactory.initElements(driver, this);
    }


    @FindBy(xpath = "//button[@data-testid='filter-dropdown-language']")
    WebElement languageTitle;

    @FindBy(xpath = "//div[text()='Language']/parent::button")
    WebElement seeMoreLanguageBtn;

    @FindBy(xpath = "//div[@class='cds-checkboxAndRadio-labelText']")
    List<WebElement> languagesDiv;

    @FindBy(xpath = "(//div[@data-testid='search-filter-group-Language']//input[@type='checkbox'])")
    List<WebElement> languageCheckBoxes;

    @FindBy(xpath = "//button[contains(translate(., 'LEVEL', 'level'), 'level')]")
    WebElement levelTitle;


    @FindBy(xpath = "//div[@data-testid='search-filter-group-Level']//div[@class='cds-checkboxAndRadio-labelText']")
    List<WebElement> levelLabels;

    @FindBy(xpath = "//div[@data-testid='search-filter-group-Level']//input[@type='checkbox']")
    List<WebElement> levelCheckBoxes;
//


    @FindBy(xpath = "//h3[contains(@class, 'cds-CommonCard-title')]")
    List<WebElement> coursesTitleList;

    @FindBy(xpath = "//div[@class='cds-RatingStat-meter']/following-sibling::span")
    List<WebElement> coursesRatingList;

    @FindBy(xpath = "//div[@class='cds-CommonCard-metadata']/p")
    List<WebElement> coursesDurationList;


    // ACTIONS
    public void scrollToLanguageTitle() {
        js.executeScript("arguments[0].scrollIntoView(true)", languageTitle);
    }

    public void scrollToLevelTitle() {
        // Wait for the button to be present and clickable
        wait.until(ExpectedConditions.elementToBeClickable(levelTitle));
        js.executeScript("arguments[0].scrollIntoView(true);", levelTitle);
        // Use JavaScript click to avoid any overlay issues
        js.executeScript("arguments[0].click();", levelTitle);

        // Wait for the Level options to become visible (ensures dropdown opened)
        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@data-testid='search-filter-group-Level']//input[@type='checkbox']")));
    }


    public void clickSeeMoreLanguages() {
        seeMoreLanguageBtn.click();
    }

    public void selectLanguage(String language) {
        languages = new ArrayList<>();
        for (WebElement ldiv: languagesDiv) {
            String lang = ldiv.getText();
            int bracketIdx = lang.indexOf("(");
            languages.add(lang.substring(0, bracketIdx).trim());
        }
        int laIdx = languages.indexOf(language);
        languageCheckBoxes.get(laIdx).click();
        System.out.println("\nSelected Language :: " + language);
    }

    public void printAllLanguages() {
        System.out.println("\nTotal no of languages :: " + languages.size());
        for (String language: languages) {
            System.out.println(language);
        }

    }

    public void selectLevel(String level) throws InterruptedException {
        // Wait for the level options to be visible
        wait.withTimeout(Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfAllElements(levelLabels));

        levels = new ArrayList<>();
        for (WebElement label : levelLabels) {
            String lev = label.getText();
            int bracketIdx = lev.indexOf("(");
            String levelName = bracketIdx > 0 ? lev.substring(0, bracketIdx).trim() : lev.trim();
            levels.add(levelName);
        }

        int leIdx = levels.indexOf(level);
        if (leIdx >= 0) {
            js.executeScript("arguments[0].click();", levelCheckBoxes.get(leIdx));
            System.out.println("\nSelected Level :: " + level);
            // Wait for page to update after selection
            Thread.sleep(2000);
        } else {
            throw new RuntimeException("Level '" + level + "' not found in the list.");
        }
    }

    public void printAllLevels() {
        wait.withTimeout(Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOfAllElements(levelLabels));
        levels = new ArrayList<>();
        for (WebElement label : levelLabels) {
            String lev = label.getText();
            int bracketIdx = lev.indexOf("(");
            String levelName = bracketIdx > 0 ? lev.substring(0, bracketIdx).trim() : lev.trim();
            levels.add(levelName);
        }
        System.out.println("\nTotal no of levels :: " + levels.size());
        for (String level : levels) {
            System.out.println(level);
        }
    }

    public void scrollToRenderCourses() throws InterruptedException {
        int idx = 4;
        while (idx > 0) {
            js.executeScript("window.scrollBy(0, 900);");
            Thread.sleep(1500);
            idx--;
        }
    }

    public List<Course> getCourses(int noOfCourse) {
        List<Course> courses = new ArrayList<>();
        for (int i = 0; i < noOfCourse; i++) {
            Course c = new Course();
            c.setTitle(coursesTitleList.get(i).getText());
            c.setRating(coursesRatingList.get(i).getText());

            String duration = coursesDurationList.get(i).getText();
            c.setDuration(duration.substring(duration.lastIndexOf("·") + 1).trim());
            courses.add(c);
        }
        return courses;
    }

    public void navigateBackToHome() throws InterruptedException {
        driver.navigate().to("https://www.coursera.org/");
        System.out.println("\nNavigated to Home Screen...");
        Thread.sleep(1000);
    }
}