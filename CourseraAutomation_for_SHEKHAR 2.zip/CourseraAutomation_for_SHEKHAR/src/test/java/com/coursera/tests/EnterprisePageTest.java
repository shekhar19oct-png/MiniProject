package com.coursera.tests;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.coursera.exception.CourseraException;
import com.coursera.pages.EnterprisePage;
import com.coursera.utils.ExcelUtil;

public class EnterprisePageTest extends BaseTest {

    private static final Logger logger = LogManager.getLogger(EnterprisePageTest.class);
    private final ExcelUtil excelUtil = new ExcelUtil();

    @Test(priority = 14)
    public void testScrollToEnterprise() {
        try {
            EnterprisePage enterprisePage = new EnterprisePage(driver);
            enterprisePage.scrollToEnterprise();
            logger.info("testScrollToEnterprise :: PASSED !!");
        } catch (Exception | Error e) {
            logger.error("testScrollToEnterprise :: FAILED !!!");
            throw new CourseraException(e.getMessage());
        }
    }

    @Test(priority = 15)
    public void testNavigateToEnterprise() {
        try {
            EnterprisePage enterprisePage = new EnterprisePage(driver);
            enterprisePage.navigateToEnterprise();
            logger.info("testNavigateToEnterprise :: PASSED !!");
        } catch (Exception | Error e) {
            logger.error("testNavigateToEnterprise :: FAILED !!!");
            throw new CourseraException(e.getMessage());
        }
    }

    @DataProvider(name = "formData")
    public Object[][] formData() throws IOException {
        List<String[]> details = excelUtil.readFormDetails();
        Object[][] data = new Object[details.size()][];
        for (int i = 0; i < details.size(); i++) {
            data[i] = details.get(i);
        }
        return data;
    }

    @Test(priority = 16, dataProvider = "formData")
    public void testFillForm(String firstName, String lastName, String email,
                             String phone, String jobTitle, String company) {
        try {
            EnterprisePage enterprisePage = new EnterprisePage(driver);

            enterprisePage.debugPrintAllFields();

            System.out.println("\n========== Filling Form ==========");
            System.out.println("First Name      : " + firstName);
            System.out.println("Last Name       : " + lastName);
            System.out.println("Email           : " + email);
            System.out.println("Phone           : " + phone);
            System.out.println("Job Title       : " + jobTitle);
            System.out.println("Company     : " + company);
            System.out.println("Organization    : Business");
            System.out.println("Needs           : Courses for myself");
            System.out.println("Country         : India");
            System.out.println("===================================\n");

            enterprisePage.fillForm(
                    firstName,
                    lastName,
                    email,
                    phone,
                    "Business",
                    jobTitle
                    ,
                    "Courses for myself",
                    "India"
            );

            Thread.sleep(2000);
            enterprisePage.clickSubmit();
            Thread.sleep(5000);

            if (enterprisePage.isErrorMsgDisplayed()) {
                System.out.println("Error: " + enterprisePage.getErrorMessage());
                Assert.fail("Form submission failed: " + enterprisePage.getErrorMessage());
            }

            String pageTitle = driver.getTitle();
            System.out.println("Page Title: " + pageTitle);

            Assert.assertTrue(
                    pageTitle.toLowerCase().contains("thank") ||
                            pageTitle.toLowerCase().contains("interest"),
                    "Submission failed - Title: " + pageTitle
            );

            logger.info("testFillForm :: PASSED !!");

            driver.navigate().back();
            Thread.sleep(2000);

        } catch (Exception | Error e) {
            logger.error("testFillForm :: FAILED !!! Error: " + e.getMessage());
            throw new CourseraException(e.getMessage());
        }
    }
}

