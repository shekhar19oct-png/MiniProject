package com.coursera.utils;

import java.time.Duration;

import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import com.coursera.exception.CourseraException;

public class DriverSetup {

    // creates driver instance
    @Getter
    private static WebDriver driver;

    // logger for logging info and errs
    private static final Logger logger = LogManager.getLogger(DriverSetup.class);

    // initializing driver based on browser and URL
    public static void initializeDriver(String browser, String url) throws CourseraException {
        if (driver == null) {
            try {
                logger.info("Initializing Browser for :: {}", browser);
                String selectedBrowser = browser == null ? "" : browser.toLowerCase();
                switch (selectedBrowser) {
                    case "edge":
                        try {
                            driver = new EdgeDriver();
                        } catch (WebDriverException edgeInitException) {
                            logger.warn("Edge driver initialization failed. Falling back to Chrome. Cause: {}", edgeInitException.getMessage());
                            driver = new ChromeDriver();
                        }
                        break;
                    case "chrome":
                        driver = new ChromeDriver();
                        break;
                    default:
                        logger.error("INVALID BROWSER :: {}", browser);
                        throw new CourseraException("Invalid browser: " + browser + ". Supported values: edge, chrome");
                }
                driver.manage().window().maximize();
                driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
                driver.get(url);
            } catch (Exception e) {
                logger.error("Driver Initialization FAILED !!!");
                throw new CourseraException("Unable to initialize WebDriver: " + e.getMessage());
            }
        }
    }

    // method to quit the instance
    public static void quitDriver() {
        if (driver != null) {
            driver.quit();
            driver = null;
        }
    }
}
