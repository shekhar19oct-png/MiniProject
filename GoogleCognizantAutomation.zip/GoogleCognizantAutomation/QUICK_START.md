# Quick Start Guide

## Prerequisites Check
- [ ] Java JDK 11+ installed (`java -version`)
- [ ] Maven installed (`mvn -version`)
- [ ] Chrome browser installed
- [ ] Firefox browser installed (optional, can test with Chrome only)

## Step-by-Step Setup

### 1. Navigate to Project Directory
```bash
cd /Users/shekharkumar/Desktop/GoogleCognizantAutomation
```

### 2. Verify Excel File
Ensure `src/resources/testdata/SearchData.xlsx` exists with:
- Row 0: Header (e.g., "SearchText")
- Row 1: Data (e.g., "Cognizant")

### 3. Build Project
```bash
mvn clean compile
```

### 4. Run Tests

#### Option A: Run All Tests (Chrome + Firefox)
```bash
mvn test
```

#### Option B: Run Only Chrome
Edit `testng.xml` and comment out Firefox test, then:
```bash
mvn test
```

#### Option C: Run from IDE
1. Open project in IntelliJ IDEA / Eclipse
2. Right-click on `testng.xml`
3. Select "Run 'testng.xml'"

### 5. View Results
- **Console**: Check console output for detailed logs
- **Screenshots**: Check `screenshots/` folder
- **Test Reports**: Check `target/surefire-reports/` after execution

## Expected Output

### Console Output Should Show:
```
=========================================
Setting up browser: chrome
=========================================
Successfully launched chrome browser and navigated to https://www.google.com

--- Step 1: Finding all links on Google home page ---
=========================================
Finding all links on Google home page...
Total Links Found: XX
=========================================
[Link details...]

--- Step 2: Typing search text ---
Typed search text: Cognizant

--- Step 3: Finding search suggestions ---
=========================================
Finding search suggestions...
Suggestions Count: X
=========================================
[Suggestion details...]
Screenshot saved: screenshots/SearchSuggestions_YYYYMMDD_HHMMSS.png

--- Step 4: Clicking Google Search button ---
Clicked Google Search button

--- Step 5: Getting search results count ---
=========================================
Search Results Count: About XXX,XXX,XXX results
=========================================

--- Step 6: Clicking 'All' tab ---
Clicked on 'All' tab
All tab - Result count: About XXX,XXX,XXX results
Full page screenshot saved: screenshots/AllResults_full_YYYYMMDD_HHMMSS.png

[Similar for News, Images, Videos tabs...]

=========================================
Test completed successfully!
=========================================
```

## Troubleshooting

### Issue: Browser not launching
**Solution**: 
- Check if Chrome/Firefox is installed
- Verify internet connection (for WebDriverManager)
- Check browser version compatibility

### Issue: Excel file not found
**Solution**: 
- Default value "Cognizant" will be used
- Create Excel file if needed: `src/resources/testdata/SearchData.xlsx`

### Issue: Elements not found
**Solution**: 
- Google page structure may have changed
- Check console for specific error messages
- Increase wait timeout in `WaitUtils.java` if needed

### Issue: Screenshots not saving
**Solution**: 
- Check `screenshots/` folder exists
- Verify write permissions
- Check disk space

## Test Execution Time
- Approximate time: 2-3 minutes per browser
- With both browsers: 4-6 minutes total

## Next Steps
1. Review `README.md` for detailed documentation
2. Check `PROJECT_STRUCTURE.md` for folder organization
3. Customize test data in Excel file
4. Modify `config.properties` for different URLs/browsers
