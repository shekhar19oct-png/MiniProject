# Google Cognizant Automation Project

## Project Overview
This project automates the Google search functionality for "Cognizant" and performs various validations and screenshots as per the requirements.

## Requirements Implemented

### Functional Requirements
1. ✅ Open https://www.google.com/
2. ✅ Find the number of links in the web page
3. ✅ Print all link names
4. ✅ Type "Cognizant" in search text box (from Excel file)
5. ✅ Find the number of search options displayed
6. ✅ Take screenshot of the options displayed
7. ✅ Print all search options
8. ✅ Click on Google Search button
9. ✅ Find the number of search results displayed as "About XXXXX results"
10. ✅ Click "All" in Google, display count, take full page screenshot
11. ✅ Click "News" in Google, display count, take full page screenshot
12. ✅ Click "Images" in Google, take full page screenshot
13. ✅ Click "Videos" in Google, display count, take full page screenshot
14. ✅ Close the browser

### Technical Requirements
1. ✅ **Multiple Browsers**: Chrome and Firefox support
2. ✅ **Synchronization**: Uses WebDriverWait instead of Thread.sleep
3. ✅ **Input Controls**: Handles text boxes and buttons
4. ✅ **Exception Handling**: Comprehensive try-catch blocks with error messages
5. ✅ **Locators**: Uses ID and Name locators (minimal XPath)
6. ✅ **Reusable Methods**: Separate utility classes for better readability
7. ✅ **Data Driven**: Excel file integration using Apache POI
8. ✅ **Relative Paths**: All file paths are relative
9. ✅ **Coding Standards**: Proper naming conventions, headers, and comments
10. ✅ **Folder Structure**: Organized folders for scripts, resources, test results
11. ✅ **Page Object Model (POM)**: Separate page classes
12. ✅ **TestNG Framework**: Test execution and reporting
13. ✅ **Screenshots**: Normal and full page screenshot support

## Project Structure

```
GoogleCognizantAutomation/
├── src/
│   ├── main/
│   │   └── java/
│   │       ├── base/
│   │       │   └── BaseTest.java              # Base test class with setup/teardown
│   │       ├── pages/
│   │       │   ├── GoogleHomePage.java        # POM for Google home page
│   │       │   └── GoogleSearchResultsPage.java # POM for search results page
│   │       └── utils/
│   │           ├── BrowserFactory.java         # Browser initialization
│   │           ├── ConfigReader.java           # Properties file reader
│   │           ├── ExcelUtils.java             # Excel file reader (Apache POI)
│   │           ├── ScreenshotUtils.java        # Screenshot utilities
│   │           └── WaitUtils.java              # Synchronization utilities
│   └── resources/
│       ├── config/
│       │   └── config.properties               # Configuration file
│       └── testdata/
│           └── SearchData.xlsx                 # Test data (Excel file)
│   └── test/
│       └── java/
│           └── tests/
│               └── GoogleSearchTest.java       # Main test class
├── screenshots/                                 # Screenshot output folder
├── test-results/                                # Test results folder
│   ├── screenshots/                             # Test result screenshots
│   └── logs/                                    # Test logs
├── pom.xml                                      # Maven dependencies
├── testng.xml                                   # TestNG configuration
└── README.md                                    # This file
```

## Prerequisites

1. **Java JDK 11 or higher**
2. **Maven 3.6+**
3. **Chrome Browser** (latest version)
4. **Firefox Browser** (latest version)
5. **IDE** (IntelliJ IDEA / Eclipse / VS Code)

## Setup Instructions

### 1. Clone/Download the Project
```bash
cd /path/to/GoogleCognizantAutomation
```

### 2. Install Dependencies
```bash
mvn clean install
```

### 3. Configure Test Data
- Ensure `src/resources/testdata/SearchData.xlsx` exists
- Excel file should have:
  - Row 0: Header (e.g., "SearchText")
  - Row 1: Data (e.g., "Cognizant")

### 4. Configure Properties
- Edit `src/resources/config/config.properties`:
  ```
  browser=chrome
  url=https://www.google.com
  ```

## Running Tests

### Run All Tests (Chrome and Firefox)
```bash
mvn test
```
or
```bash
mvn clean test
```

### Run Specific Browser
Edit `testng.xml` and comment out the browser you don't want to test, or run:
```bash
mvn test -Dbrowser=chrome
```

### Run from IDE
1. Right-click on `testng.xml`
2. Select "Run" or "Debug"

### Run from Command Line
```bash
mvn test -DsuiteXmlFile=testng.xml
```

## Test Execution Flow

1. **Setup**: Browser launches (Chrome/Firefox)
2. **Step 1**: Find and print all links on Google home page
3. **Step 2**: Type "Cognizant" in search box (from Excel)
4. **Step 3**: Find and print search suggestions, take screenshot
5. **Step 4**: Click Google Search button
6. **Step 5**: Get result count, take full page screenshot
7. **Step 6**: Click "All" tab, display count, take full page screenshot
8. **Step 7**: Click "News" tab, display count, take full page screenshot
9. **Step 8**: Click "Images" tab, take full page screenshot
10. **Step 9**: Click "Videos" tab, display count, take full page screenshot
11. **Teardown**: Close browser

## Key Features

### Page Object Model (POM)
- `GoogleHomePage`: Handles home page interactions
- `GoogleSearchResultsPage`: Handles search results page interactions

### Utility Classes
- **BrowserFactory**: Multi-browser support with exception handling
- **ConfigReader**: Reads configuration from properties file
- **ExcelUtils**: Reads test data from Excel using Apache POI
- **ScreenshotUtils**: Takes normal and full page screenshots
- **WaitUtils**: Implements WebDriverWait for synchronization

### Exception Handling
- All methods have try-catch blocks
- Error messages logged to console
- Screenshots taken on test failure

### Synchronization
- Uses `WebDriverWait` with explicit waits
- No `Thread.sleep()` statements (except minimal waits for suggestions)
- Page load wait implemented

### Locators
- Primarily uses **ID** and **Name** locators
- Minimal use of XPath (only when necessary)
- CSS selectors used as fallback

## Screenshots

Screenshots are saved in the `screenshots/` folder with timestamps:
- `SearchSuggestions_YYYYMMDD_HHMMSS.png`
- `AllResults_full_YYYYMMDD_HHMMSS.png`
- `NewsResults_full_YYYYMMDD_HHMMSS.png`
- `ImagesResults_full_YYYYMMDD_HHMMSS.png`
- `VideosResults_full_YYYYMMDD_HHMMSS.png`

## Test Results

Test execution results are displayed in:
- Console output (detailed logs)
- TestNG HTML reports (after execution)
- Screenshots folder

## Troubleshooting

### Browser Not Launching
- Ensure Chrome/Firefox is installed
- Check WebDriverManager is downloading drivers correctly
- Verify internet connection for driver downloads

### Excel File Not Found
- Ensure `SearchData.xlsx` exists in `src/resources/testdata/`
- Check file permissions
- Default value "Cognizant" will be used if Excel read fails

### Element Not Found
- Google page structure may have changed
- Check locators in page classes
- Increase wait timeout in `WaitUtils.java`

### Screenshot Failures
- Ensure `screenshots/` folder exists
- Check write permissions
- Verify disk space

## Dependencies

All dependencies are managed in `pom.xml`:
- Selenium Java 4.17.0
- TestNG 7.9.0
- Apache POI 5.2.5
- WebDriverManager 5.6.3
- SLF4J 2.0.9

## Coding Standards

- ✅ Proper package structure
- ✅ Meaningful class and method names
- ✅ JavaDoc comments for all classes and methods
- ✅ Exception handling with meaningful messages
- ✅ Console logging for debugging
- ✅ Relative paths throughout
- ✅ Reusable utility methods

## Author
Automation Team

## Version
1.0

## License
This project is for educational/training purposes.
