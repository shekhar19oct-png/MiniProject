@echo off
REM Google Cognizant Automation - Test Runner Script (Windows)
REM This script helps you run the tests easily on Windows

echo =========================================
echo Google Cognizant Automation - Test Runner
echo =========================================
echo.

REM Check Java
echo Checking Java installation...
java -version >nul 2>&1
if %errorlevel% equ 0 (
    java -version
    echo [OK] Java is installed
) else (
    echo [ERROR] Java is NOT installed
    echo Please install Java JDK 11 or higher
    echo Download from: https://www.oracle.com/java/technologies/downloads/
    pause
    exit /b 1
)

echo.

REM Check Maven
echo Checking Maven installation...
mvn --version >nul 2>&1
if %errorlevel% equ 0 (
    mvn --version
    echo [OK] Maven is installed
) else (
    echo [ERROR] Maven is NOT installed
    echo Please install Maven from: https://maven.apache.org/download.cgi
    pause
    exit /b 1
)

echo.
echo =========================================
echo Starting test execution...
echo =========================================
echo.

REM Navigate to script directory
cd /d "%~dp0"

REM Clean and compile
echo Step 1: Cleaning and compiling...
call mvn clean compile

if %errorlevel% neq 0 (
    echo [ERROR] Compilation failed. Please check errors above.
    pause
    exit /b 1
)

echo.
echo Step 2: Running tests...
echo.

REM Run tests
call mvn test

REM Check result
if %errorlevel% equ 0 (
    echo.
    echo =========================================
    echo [OK] Tests completed successfully!
    echo =========================================
    echo.
    echo Check the following for results:
    echo - Console output above for detailed logs
    echo - screenshots\ folder for screenshots
    echo - target\surefire-reports\ for test reports
) else (
    echo.
    echo =========================================
    echo [ERROR] Tests failed. Check errors above.
    echo =========================================
)

pause
