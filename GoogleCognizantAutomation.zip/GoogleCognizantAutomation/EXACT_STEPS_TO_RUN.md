# Exact Steps to Run the Tests

## 🚀 Quick Start (3 Steps)

### Step 1: Install Prerequisites

#### On macOS:
```bash
# Install Java (if not installed)
brew install openjdk@11

# Install Maven (if not installed)
brew install maven

# Verify installations
java -version
mvn --version
```

#### On Windows:
1. Download Java JDK 11+ from: https://www.oracle.com/java/technologies/downloads/
2. Download Maven from: https://maven.apache.org/download.cgi
3. Add both to PATH environment variable
4. Verify: Open Command Prompt and run:
   ```cmd
   java -version
   mvn --version
   ```

### Step 2: Navigate to Project
```bash
cd /Users/shekharkumar/Desktop/GoogleCognizantAutomation
```

### Step 3: Run Tests

**Option A: Using the script (Easiest)**
```bash
# macOS/Linux
./run-tests.sh

# Windows
run-tests.bat
```

**Option B: Using Maven directly**
```bash
mvn clean test
```

---

## 📋 Detailed Step-by-Step Instructions

### Method 1: Command Line (Maven)

#### Step 1: Open Terminal/Command Prompt
- **macOS**: Open Terminal app
- **Windows**: Open Command Prompt or PowerShell

#### Step 2: Navigate to Project
```bash
cd /Users/shekharkumar/Desktop/GoogleCognizantAutomation
```

#### Step 3: Clean Previous Builds (Optional)
```bash
mvn clean
```

#### Step 4: Compile the Project
```bash
mvn compile
```
**Expected**: Should show "BUILD SUCCESS" after downloading dependencies (first time takes 2-3 minutes)

#### Step 5: Run Tests
```bash
mvn test
```

**What You'll See:**
1. Browser (Chrome) will open automatically
2. Test will execute all steps:
   - Find links on Google
   - Type "Cognizant" and show suggestions
   - Click search
   - Navigate through All, News, Images, Videos tabs
   - Take screenshots
3. Browser will close automatically
4. Console will show "BUILD SUCCESS"

#### Step 6: Check Results
- **Screenshots**: Open `screenshots/` folder
- **Test Reports**: Open `target/surefire-reports/index.html` in browser
- **Console**: Scroll up to see detailed logs

---

### Method 2: Using IntelliJ IDEA (Recommended for Beginners)

#### Step 1: Open Project
1. Open IntelliJ IDEA
2. Click **File** → **Open**
3. Select the `GoogleCognizantAutomation` folder
4. Click **Open**
5. Wait for Maven to sync (bottom right corner, click "Import Maven Project" if prompted)

#### Step 2: Wait for Indexing
- IntelliJ will download dependencies automatically
- Wait until bottom right shows "Indexing..." is complete
- This may take 2-3 minutes first time

#### Step 3: Run Tests

**Option A: Run via testng.xml (Recommended)**
1. In Project Explorer (left panel), find `testng.xml`
2. Right-click on `testng.xml`
3. Select **"Run 'testng.xml'"**

**Option B: Run via Test Class**
1. Open `src/test/java/tests/GoogleSearchTest.java`
2. Right-click on the class name `GoogleSearchTest`
3. Select **"Run 'GoogleSearchTest'"**

**Option C: Run via Maven**
1. Open Maven tool window: **View** → **Tool Windows** → **Maven**
2. Expand `GoogleCognizantAutomation` → `Lifecycle`
3. Double-click `test`

#### Step 4: Watch Test Execute
- Browser will open automatically
- You'll see the test steps executing
- Browser will close when done

#### Step 5: View Results
- **Console Tab**: Shows detailed logs
- **Test Results Tab**: Shows test summary
- **Screenshots**: Check `screenshots/` folder in project

---

### Method 3: Using Eclipse

#### Step 1: Import Project
1. Open Eclipse
2. **File** → **Import**
3. **Maven** → **Existing Maven Projects**
4. Browse to `GoogleCognizantAutomation` folder
5. Click **Finish**

#### Step 2: Install TestNG Plugin (if not installed)
1. **Help** → **Eclipse Marketplace**
2. Search for "TestNG"
3. Install "TestNG for Eclipse"
4. Restart Eclipse

#### Step 3: Run Tests
1. Right-click on `testng.xml`
2. **Run As** → **TestNG Suite**

---

## 🎯 All Available Run Options

### Option 1: Run All Tests (Chrome)
```bash
mvn test
```

### Option 2: Run Only Chrome (Already configured)
- `testng.xml` is already set to run Chrome only
- Just run: `mvn test`

### Option 3: Run Only Firefox
1. Edit `testng.xml`
2. Comment out Chrome test, uncomment Firefox test
3. Run: `mvn test`

### Option 4: Run Both Browsers
1. Edit `testng.xml`
2. Uncomment both Chrome and Firefox tests
3. Run: `mvn test`

### Option 5: Run with Verbose Output
```bash
mvn test -X
```

### Option 6: Skip Tests, Just Build
```bash
mvn clean install -DskipTests
```

---

## 🔍 What to Expect During Execution

### Console Output Will Show:
```
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
=========================================
Setting up browser: chrome
=========================================
Successfully launched chrome browser...

--- Step 1: Finding all links on Google home page ---
Total Links Found: XX
[Link details...]

--- Step 2: Typing search text ---
Typed search text: Cognizant

--- Step 3: Finding search suggestions ---
Suggestions Count: X
[Suggestion details...]
Screenshot saved: screenshots/SearchSuggestions_YYYYMMDD_HHMMSS.png

--- Step 4: Clicking Google Search button ---
Clicked Google Search button

--- Step 5: Getting search results count ---
Search Results Count: About XXX,XXX,XXX results

--- Step 6: Clicking 'All' tab ---
[Similar steps for News, Images, Videos...]

=========================================
Test completed successfully!
=========================================

[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

### Screenshots Created:
- `SearchSuggestions_YYYYMMDD_HHMMSS.png`
- `AllResults_full_YYYYMMDD_HHMMSS.png`
- `NewsResults_full_YYYYMMDD_HHMMSS.png`
- `ImagesResults_full_YYYYMMDD_HHMMSS.png`
- `VideosResults_full_YYYYMMDD_HHMMSS.png`

---

## ⚠️ Common Issues & Solutions

### Issue 1: "mvn: command not found"
**Solution**: Install Maven
- macOS: `brew install maven`
- Windows: Download from Apache Maven website

### Issue 2: "java: command not found"
**Solution**: Install Java JDK 11+
- macOS: `brew install openjdk@11`
- Windows: Download from Oracle website

### Issue 3: "BUILD FAILURE" - Dependencies not downloading
**Solution**: 
- Check internet connection
- Try: `mvn clean install -U`
- Check firewall/proxy settings

### Issue 4: Browser doesn't open
**Solution**:
- Ensure Chrome is installed
- Check internet (WebDriverManager needs to download drivers)
- Try running again (drivers download on first run)

### Issue 5: "FileNotFoundException" for Excel
**Solution**:
- Test will use default "Cognizant" if Excel fails
- Create Excel file: `src/resources/testdata/SearchData.xlsx`
- Row 0: "SearchText", Row 1: "Cognizant"

### Issue 6: Tests fail with timeout errors
**Solution**:
- Check internet connection
- Google might be slow, increase timeout in `WaitUtils.java`
- Try running again

---

## 📊 Test Execution Time

- **First Run**: 3-5 minutes (downloads dependencies)
- **Subsequent Runs**: 2-3 minutes per browser
- **With Screenshots**: Add 30 seconds

---

## ✅ Success Indicators

You'll know it worked if you see:
1. ✅ Browser opened and closed automatically
2. ✅ Console shows "BUILD SUCCESS"
3. ✅ Screenshots folder has 5+ screenshot files
4. ✅ Console shows all 9 steps completed
5. ✅ No error messages in red

---

## 🆘 Still Having Issues?

1. **Check Prerequisites**: Java and Maven must be installed
2. **Check Internet**: Needed for downloading dependencies and accessing Google
3. **Check Browser**: Chrome must be installed
4. **Read Error Messages**: They usually tell you what's wrong
5. **Try IDE Method**: Often easier than command line

---

## 📝 Quick Reference

```bash
# Navigate to project
cd /Users/shekharkumar/Desktop/GoogleCognizantAutomation

# Clean and test (all in one)
mvn clean test

# Or use the script
./run-tests.sh        # macOS/Linux
run-tests.bat         # Windows
```

That's it! The tests should run successfully. 🎉
