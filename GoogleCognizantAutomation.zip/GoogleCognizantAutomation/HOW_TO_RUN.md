# How to Run the Tests - Complete Guide

## Prerequisites Check

### 1. Check Java Installation
```bash
java -version
```
**Expected Output**: Should show Java version 11 or higher
- If not installed: Download from https://www.oracle.com/java/technologies/downloads/
- Or use Homebrew: `brew install openjdk@11`

### 2. Check Maven Installation
```bash
mvn --version
```
**Expected Output**: Should show Maven version 3.6 or higher
- If not installed: 
  - **macOS**: `brew install maven`
  - **Windows**: Download from https://maven.apache.org/download.cgi
  - **Linux**: `sudo apt-get install maven` or `sudo yum install maven`

### 3. Verify Project Structure
Ensure these files exist:
- `pom.xml` ✅
- `testng.xml` ✅
- `src/resources/testdata/SearchData.xlsx` ✅
- `src/resources/config/config.properties` ✅

---

## Method 1: Run Using Maven (Recommended) ⭐

### Step 1: Navigate to Project Directory
```bash
cd /Users/shekharkumar/Desktop/GoogleCognizantAutomation
```

### Step 2: Clean and Compile
```bash
mvn clean compile
```
This will:
- Download all dependencies (first time only, takes 2-3 minutes)
- Compile all Java files
- Show any compilation errors

### Step 3: Run Tests
```bash
mvn test
```

**What happens:**
- Launches Chrome browser
- Executes all test steps
- Takes screenshots
- Closes browser
- Shows test results in console

### Step 4: View Results
- **Console Output**: Detailed logs of all steps
- **Screenshots**: Check `screenshots/` folder
- **Test Reports**: Check `target/surefire-reports/` folder

---

## Method 2: Run Using IDE (IntelliJ IDEA)

### Step 1: Open Project
1. Open IntelliJ IDEA
2. File → Open → Select `GoogleCognizantAutomation` folder
3. Wait for Maven to sync (bottom right corner)

### Step 2: Run Tests
**Option A: Run via testng.xml**
1. Right-click on `testng.xml` in project explorer
2. Select **"Run 'testng.xml'"**

**Option B: Run specific test class**
1. Open `src/test/java/tests/GoogleSearchTest.java`
2. Right-click on the class name or test method
3. Select **"Run 'GoogleSearchTest'"**

**Option C: Run via Maven**
1. Open Maven tool window (View → Tool Windows → Maven)
2. Expand `GoogleCognizantAutomation` → `Lifecycle`
3. Double-click `test`

### Step 3: View Results
- **Console**: Bottom panel shows test execution logs
- **Test Results**: Right panel shows TestNG results
- **Screenshots**: Check `screenshots/` folder

---

## Method 3: Run Using IDE (Eclipse)

### Step 1: Import Project
1. File → Import → Maven → Existing Maven Projects
2. Select `GoogleCognizantAutomation` folder
3. Click Finish

### Step 2: Run Tests
1. Right-click on `testng.xml`
2. Run As → TestNG Suite

---

## Method 4: Run Using Command Line (TestNG)

### Step 1: Compile Classes
```bash
cd /Users/shekharkumar/Desktop/GoogleCognizantAutomation
javac -cp "target/classes:target/test-classes:$(mvn dependency:build-classpath -q -DincludeScope=test)" src/test/java/tests/GoogleSearchTest.java
```

### Step 2: Run TestNG
```bash
java -cp "target/classes:target/test-classes:$(mvn dependency:build-classpath -q -DincludeScope=test)" org.testng.TestNG testng.xml
```

**Note**: This method is complex, prefer Maven or IDE methods.

---

## Method 5: Run Only Chrome (Quick Test)

### Edit testng.xml
Comment out Firefox test (already done):
```xml
<!-- Firefox test is commented out -->
```

### Run
```bash
mvn test
```

---

## Method 6: Run Only Firefox

### Edit testng.xml
Comment out Chrome test, uncomment Firefox:
```xml
<!-- Chrome Browser Test -->
<!--
<test name="Chrome Browser Test">
    <parameter name="browser" value="chrome"/>
    <classes>
        <class name="tests.GoogleSearchTest"/>
    </classes>
</test>
-->

<!-- Firefox Browser Test -->
<test name="Firefox Browser Test">
    <parameter name="browser" value="firefox"/>
    <classes>
        <class name="tests.GoogleSearchTest"/>
    </classes>
</test>
```

### Run
```bash
mvn test
```

---

## Troubleshooting

### Issue 1: Maven Not Found
**Error**: `command not found: mvn`

**Solution**:
- Install Maven: `brew install maven` (macOS)
- Or add Maven to PATH
- Or use IDE method instead

### Issue 2: Java Not Found
**Error**: `java: command not found`

**Solution**:
- Install Java JDK 11+
- Set JAVA_HOME environment variable
- Verify: `java -version`

### Issue 3: Dependencies Not Downloading
**Error**: Network issues, timeout

**Solution**:
- Check internet connection
- Try: `mvn clean install -U` (force update)
- Check firewall settings

### Issue 4: Browser Not Launching
**Error**: WebDriverException

**Solution**:
- Ensure Chrome/Firefox is installed
- Check WebDriverManager downloads drivers (needs internet)
- Try: Delete `~/.m2/repository/io/github/bonigarcia/webdrivermanager` and retry

### Issue 5: Excel File Not Found
**Error**: FileNotFoundException

**Solution**:
- Ensure `src/resources/testdata/SearchData.xlsx` exists
- Default value "Cognizant" will be used if Excel fails
- Create Excel file if missing:
  - Row 0: Header "SearchText"
  - Row 1: Data "Cognizant"

### Issue 6: Compilation Errors
**Error**: Cannot find symbol, package errors

**Solution**:
```bash
mvn clean
mvn compile
```
If still errors, check:
- Java version (need 11+)
- Maven version (need 3.6+)
- All files are in correct folders

---

## Expected Output

### Successful Test Run Should Show:

```
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running TestSuite
=========================================
Setting up browser: chrome
=========================================
Successfully launched chrome browser and navigated to https://www.google.com

--- Step 1: Finding all links on Google home page ---
=========================================
Finding all links on Google home page...
Total Links Found: XX
=========================================
[Link details...]

--- Step 2: Typing search text ---
Typed search text: Cognizant

--- Step 3: Finding search suggestions ---
=========================================
Finding search suggestions...
Suggestions Count: X
=========================================
[Suggestion details...]
Screenshot saved: screenshots/SearchSuggestions_YYYYMMDD_HHMMSS.png

--- Step 4: Clicking Google Search button ---
Clicked Google Search button

--- Step 5: Getting search results count ---
=========================================
Search Results Count: About XXX,XXX,XXX results
=========================================

--- Step 6: Clicking 'All' tab ---
Clicked on 'All' tab
All tab - Result count: About XXX,XXX,XXX results
Full page screenshot saved: screenshots/AllResults_full_YYYYMMDD_HHMMSS.png

[Similar for News, Images, Videos tabs...]

=========================================
Test completed successfully!
=========================================
Closing browser...
Browser closed successfully

[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

---

## Quick Reference Commands

```bash
# Navigate to project
cd /Users/shekharkumar/Desktop/GoogleCognizantAutomation

# Clean build
mvn clean

# Compile only
mvn compile

# Run tests
mvn test

# Clean, compile, and test (all in one)
mvn clean test

# Skip tests, just build
mvn clean install -DskipTests

# Run with verbose output
mvn test -X

# Run specific test class (if configured)
mvn test -Dtest=GoogleSearchTest
```

---

## Recommended Approach

**For First Time:**
1. Use **Method 1 (Maven)** - Most reliable
2. Or use **Method 2 (IntelliJ IDEA)** - Easiest if you have IDE

**For Regular Testing:**
- Use IDE for quick runs
- Use Maven for CI/CD or batch runs

---

## Test Execution Time

- **Chrome only**: ~2-3 minutes
- **Firefox only**: ~2-3 minutes  
- **Both browsers**: ~4-6 minutes

---

## Need Help?

If tests fail:
1. Check console output for specific error
2. Verify all prerequisites are installed
3. Check `screenshots/` folder for any screenshots taken
4. Review error messages in console
