# Complete Project Folder Structure

```
GoogleCognizantAutomation/
│
├── 📁 src/
│   ├── 📁 main/
│   │   └── 📁 java/
│   │       ├── 📁 base/
│   │       │   └── 📄 BaseTest.java                    # Base test class
│   │       ├── 📁 pages/                               # Page Object Model
│   │       │   ├── 📄 GoogleHomePage.java              # Google home page POM
│   │       │   └── 📄 GoogleSearchResultsPage.java     # Search results POM
│   │       └── 📁 utils/                               # Utility classes
│   │           ├── 📄 BrowserFactory.java              # Browser initialization
│   │           ├── 📄 ConfigReader.java                 # Properties reader
│   │           ├── 📄 ExcelUtils.java                   # Excel reader (POI)
│   │           ├── 📄 ScreenshotUtils.java             # Screenshot utilities
│   │           └── 📄 WaitUtils.java                   # Wait utilities
│   │
│   ├── 📁 resources/
│   │   ├── 📁 config/
│   │   │   └── 📄 config.properties                    # Configuration file
│   │   └── 📁 testdata/
│   │       └── 📄 SearchData.xlsx                       # Test data (Excel)
│   │
│   └── 📁 test/
│       └── 📁 java/
│           └── 📁 tests/
│               └── 📄 GoogleSearchTest.java             # Main test class
│
├── 📁 screenshots/                                     # Screenshot output
│   └── (Screenshots saved here during test execution)
│
├── 📁 test-results/                                    # Test results
│   ├── 📁 screenshots/                                 # Test result screenshots
│   └── 📁 logs/                                        # Test logs
│
├── 📁 target/                                          # Maven build output
│   ├── 📁 classes/                                     # Compiled classes
│   └── 📁 test-classes/                                # Compiled test classes
│
├── 📄 pom.xml                                          # Maven dependencies
├── 📄 testng.xml                                       # TestNG configuration
├── 📄 README.md                                        # Project documentation
└── 📄 PROJECT_STRUCTURE.md                            # This file
```

## File Descriptions

### Base Classes
- **BaseTest.java**: Contains @BeforeMethod and @AfterMethod for browser setup/teardown

### Page Object Model (POM)
- **GoogleHomePage.java**: 
  - Methods: findAllLinks(), typeSearchText(), findAndPrintSuggestions(), clickSearchButton()
  - Locators: Uses name="q" for search box, name="btnK" for search button
  
- **GoogleSearchResultsPage.java**:
  - Methods: getResultCount(), clickAllTab(), clickNewsTab(), clickImagesTab(), clickVideosTab()
  - Locators: Uses id="result-stats", linkText for tabs

### Utility Classes
- **BrowserFactory.java**: 
  - Supports Chrome and Firefox
  - Exception handling
  - Uses WebDriverManager
  
- **ConfigReader.java**: 
  - Reads from config.properties
  - Uses relative paths
  
- **ExcelUtils.java**: 
  - Reads test data from Excel using Apache POI
  - Returns "Cognizant" as default if Excel read fails
  
- **ScreenshotUtils.java**: 
  - Normal screenshots
  - Full page screenshots (with scrolling)
  - Timestamped filenames
  
- **WaitUtils.java**: 
  - WebDriverWait implementations
  - No Thread.sleep() (except minimal waits)
  - waitForVisibility(), waitForClickable(), waitForPageLoad()

### Test Class
- **GoogleSearchTest.java**: 
  - Implements all 9 steps of requirements
  - Extends BaseTest
  - Uses @Test annotation

### Configuration Files
- **config.properties**: Browser and URL configuration
- **testng.xml**: TestNG suite configuration for multiple browsers
- **pom.xml**: Maven dependencies and build configuration

### Test Data
- **SearchData.xlsx**: Excel file with search text (Row 1, Column 0)

## Key Features by Requirement

✅ **Multiple Browsers**: Chrome and Firefox support in BrowserFactory
✅ **POM Design**: Separate page classes for home and results pages
✅ **TestNG Framework**: testng.xml with browser parameters
✅ **Apache POI**: ExcelUtils reads from SearchData.xlsx
✅ **Screenshots**: Normal and full page screenshots
✅ **Reusable Code**: Utility classes with static methods
✅ **Exception Handling**: Try-catch blocks with error messages
✅ **Relative Paths**: All file paths are relative
✅ **ID/Name Locators**: Primarily uses ID and Name, minimal XPath
✅ **Synchronization**: WebDriverWait, no Thread.sleep()
✅ **Coding Standards**: JavaDoc comments, proper naming conventions
✅ **Folder Structure**: Organized folders for all components
