package pages;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import utils.WaitUtils;

/**
 * GoogleHomePage - Page Object Model for Google Home Page
 * Uses ID and Name locators as per requirements
 * Implements reusable methods for better maintainability
 * 
 * @author Automation Team
 * @version 1.0
 */
public class GoogleHomePage {

    WebDriver driver;

    /**
     * Constructor - Initializes PageFactory
     * 
     * @param driver - WebDriver instance
     */
    public GoogleHomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Locators using Name and ID (as per requirements)
    @FindBy(name = "q")
    WebElement searchBox;

    @FindBy(name = "btnK")
    WebElement searchButton;

    @FindBy(tagName = "a")
    List<WebElement> allLinks;

    @FindBy(css = "ul[role='listbox'] li")
    List<WebElement> suggestions;

    /**
     * Finds and prints all links on the Google home page
     * 
     * @return List of link texts
     */
    public List<String> findAllLinks() {
        try {
            WaitUtils.waitForPageLoad(driver);
            List<String> linkTexts = new ArrayList<>();
            
            System.out.println("=========================================");
            System.out.println("Finding all links on Google home page...");
            System.out.println("Total Links Found: " + allLinks.size());
            System.out.println("=========================================");
            
            for (WebElement link : allLinks) {
                try {
                    String linkText = link.getText();
                    String linkHref = link.getAttribute("href");
                    
                    if (linkText != null && !linkText.isEmpty()) {
                        linkTexts.add(linkText);
                        System.out.println("Link Text: " + linkText);
                        if (linkHref != null) {
                            System.out.println("  URL: " + linkHref);
                        }
                    }
                } catch (Exception e) {
                    // Skip links that are not visible or accessible
                    continue;
                }
            }
            
            System.out.println("=========================================");
            System.out.println("Total valid links printed: " + linkTexts.size());
            System.out.println("=========================================");
            
            return linkTexts;
            
        } catch (Exception e) {
            System.err.println("Error finding links: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    /**
     * Types search text in the search box
     * 
     * @param text - Text to search
     */
    public void typeSearchText(String text) {
        try {
            WaitUtils.waitForVisibility(driver, searchBox);
            searchBox.clear();
            searchBox.sendKeys(text);
            System.out.println("Typed search text: " + text);
        } catch (Exception e) {
            System.err.println("Error typing search text: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Finds and prints all search suggestions displayed
     * 
     * @return List of suggestion texts
     */
    public List<String> findAndPrintSuggestions() {
        try {
            WaitUtils.wait(2); // Wait for suggestions to appear
            List<String> suggestionTexts = new ArrayList<>();
            
            System.out.println("=========================================");
            System.out.println("Finding search suggestions...");
            System.out.println("Suggestions Count: " + suggestions.size());
            System.out.println("=========================================");
            
            for (WebElement suggestion : suggestions) {
                try {
                    String suggestionText = suggestion.getText();
                    if (suggestionText != null && !suggestionText.isEmpty()) {
                        suggestionTexts.add(suggestionText);
                        System.out.println("Suggestion: " + suggestionText);
                    }
                } catch (Exception e) {
                    continue;
                }
            }
            
            System.out.println("=========================================");
            System.out.println("Total suggestions printed: " + suggestionTexts.size());
            System.out.println("=========================================");
            
            return suggestionTexts;
            
        } catch (Exception e) {
            System.err.println("Error finding suggestions: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    /**
     * Clicks the Google Search button
     */
    public void clickSearchButton() {
        try {
            // Try clicking the visible search button
            try {
                WaitUtils.waitForClickable(driver, searchButton);
                searchButton.click();
                System.out.println("Clicked Google Search button");
            } catch (Exception e) {
                // If button not found, press Enter key
                System.out.println("Search button not found, pressing Enter key");
                searchBox.sendKeys(Keys.ENTER);
            }
            
            WaitUtils.waitForPageLoad(driver);
            
        } catch (Exception e) {
            System.err.println("Error clicking search button: " + e.getMessage());
            // Fallback: press Enter
            searchBox.sendKeys(Keys.ENTER);
            WaitUtils.waitForPageLoad(driver);
        }
    }
}
