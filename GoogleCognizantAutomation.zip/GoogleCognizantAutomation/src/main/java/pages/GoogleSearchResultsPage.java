package pages;

import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import utils.WaitUtils;

/**
 * GoogleSearchResultsPage - Page Object Model for Google Search Results Page
 * Handles navigation between All, News, Images, Videos tabs
 * Uses ID and Name locators as per requirements
 * 
 * @author Automation Team
 * @version 1.0
 */
public class GoogleSearchResultsPage {

    WebDriver driver;

    /**
     * Constructor - Initializes PageFactory
     * 
     * @param driver - WebDriver instance
     */
    public GoogleSearchResultsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Locators using ID, Name, and CSS selectors
    @FindBy(id = "result-stats")
    WebElement resultStats;

    // Navigation tabs - using linkText and partialLinkText
    @FindBy(linkText = "All")
    WebElement allTab;

    @FindBy(linkText = "News")
    WebElement newsTab;

    @FindBy(linkText = "Images")
    WebElement imagesTab;

    @FindBy(linkText = "Videos")
    WebElement videosTab;

    /**
     * Gets and prints the result count from "About XXXXX results"
     * 
     * @return Result count text
     */
    public String getResultCount() {
        try {
            WaitUtils.waitForVisibility(driver, resultStats);
            String resultText = resultStats.getText();
            System.out.println("=========================================");
            System.out.println("Search Results Count: " + resultText);
            System.out.println("=========================================");
            return resultText;
        } catch (Exception e) {
            System.err.println("Error getting result count: " + e.getMessage());
            return "Result count not available";
        }
    }

    /**
     * Clicks on "All" tab and displays count
     * 
     * @return Result count text
     */
    public String clickAllTab() {
        try {
            WaitUtils.waitForClickable(driver, allTab);
            allTab.click();
            System.out.println("Clicked on 'All' tab");
            WaitUtils.waitForPageLoad(driver);
            WaitUtils.wait(2);
            
            String count = getResultCount();
            System.out.println("All tab - Result count: " + count);
            return count;
            
        } catch (Exception e) {
            System.err.println("Error clicking All tab: " + e.getMessage());
            e.printStackTrace();
            return "Error getting count";
        }
    }

    /**
     * Clicks on "News" tab and displays count
     * 
     * @return Result count text
     */
    public String clickNewsTab() {
        try {
            WaitUtils.waitForClickable(driver, newsTab);
            newsTab.click();
            System.out.println("Clicked on 'News' tab");
            WaitUtils.waitForPageLoad(driver);
            WaitUtils.wait(2);
            
            try {
                String count = getResultCount();
                System.out.println("News tab - Result count: " + count);
                return count;
            } catch (Exception e) {
                System.out.println("News tab - Result count not available");
                return "Count not available";
            }
            
        } catch (Exception e) {
            System.err.println("Error clicking News tab: " + e.getMessage());
            e.printStackTrace();
            return "Error getting count";
        }
    }

    /**
     * Clicks on "Images" tab
     */
    public void clickImagesTab() {
        try {
            WaitUtils.waitForClickable(driver, imagesTab);
            imagesTab.click();
            System.out.println("Clicked on 'Images' tab");
            WaitUtils.waitForPageLoad(driver);
            WaitUtils.wait(2);
        } catch (Exception e) {
            System.err.println("Error clicking Images tab: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Clicks on "Videos" tab and displays count
     * 
     * @return Result count text if available
     */
    public String clickVideosTab() {
        try {
            WaitUtils.waitForClickable(driver, videosTab);
            videosTab.click();
            System.out.println("Clicked on 'Videos' tab");
            WaitUtils.waitForPageLoad(driver);
            WaitUtils.wait(2);
            
            try {
                String count = getResultCount();
                System.out.println("Videos tab - Result count: " + count);
                return count;
            } catch (Exception e) {
                System.out.println("Videos tab - Result count not available");
                return "Count not available";
            }
            
        } catch (Exception e) {
            System.err.println("Error clicking Videos tab: " + e.getMessage());
            e.printStackTrace();
            return "Error getting count";
        }
    }
}
