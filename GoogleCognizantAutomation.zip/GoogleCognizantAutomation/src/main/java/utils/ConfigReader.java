package utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * ConfigReader - Utility class for reading configuration from properties file
 * Uses relative paths for better portability
 * 
 * @author Automation Team
 * @version 1.0
 */
public class ConfigReader {
    
    private static Properties properties;
    private static final String CONFIG_FILE_PATH = "src/resources/config/config.properties";
    
    /**
     * Loads properties from config file
     */
    static {
        try {
            properties = new Properties();
            InputStream inputStream = new FileInputStream(CONFIG_FILE_PATH);
            properties.load(inputStream);
            inputStream.close();
            System.out.println("Configuration file loaded successfully");
        } catch (Exception e) {
            System.err.println("Error loading configuration file: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Gets property value by key
     * 
     * @param key - Property key
     * @return Property value
     */
    public static String getProperty(String key) {
        String value = properties.getProperty(key);
        if (value == null) {
            System.err.println("Property not found: " + key);
        }
        return value;
    }
    
    /**
     * Gets property value with default value
     * 
     * @param key - Property key
     * @param defaultValue - Default value if key not found
     * @return Property value or default value
     */
    public static String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }
}
