package utils;

import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

/**
 * WaitUtils - Utility class for handling synchronization
 * Uses WebDriverWait instead of Thread.sleep for better performance
 * Implements industry standard best practices for page synchronization
 * 
 * @author Automation Team
 * @version 1.0
 */
public class WaitUtils {
    
    private static final int DEFAULT_TIMEOUT = 15;
    
    /**
     * Waits for element to be visible
     * 
     * @param driver - WebDriver instance
     * @param element - WebElement to wait for
     */
    public static void waitForVisibility(WebDriver driver, WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(DEFAULT_TIMEOUT));
            wait.until(ExpectedConditions.visibilityOf(element));
        } catch (TimeoutException e) {
            System.err.println("Element not visible within " + DEFAULT_TIMEOUT + " seconds: " + e.getMessage());
            throw e;
        }
    }
    
    /**
     * Waits for element to be clickable
     * 
     * @param driver - WebDriver instance
     * @param element - WebElement to wait for
     */
    public static void waitForClickable(WebDriver driver, WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(DEFAULT_TIMEOUT));
            wait.until(ExpectedConditions.elementToBeClickable(element));
        } catch (TimeoutException e) {
            System.err.println("Element not clickable within " + DEFAULT_TIMEOUT + " seconds: " + e.getMessage());
            throw e;
        }
    }
    
    /**
     * Waits for element to be present in DOM
     * 
     * @param driver - WebDriver instance
     * @param locator - By locator
     */
    public static void waitForPresence(WebDriver driver, By locator) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(DEFAULT_TIMEOUT));
            wait.until(ExpectedConditions.presenceOfElementLocated(locator));
        } catch (TimeoutException e) {
            System.err.println("Element not present within " + DEFAULT_TIMEOUT + " seconds: " + e.getMessage());
            throw e;
        }
    }
    
    /**
     * Waits for page to load completely
     * 
     * @param driver - WebDriver instance
     */
    public static void waitForPageLoad(WebDriver driver) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(DEFAULT_TIMEOUT));
            wait.until(webDriver -> ((JavascriptExecutor) webDriver)
                    .executeScript("return document.readyState").equals("complete"));
        } catch (TimeoutException e) {
            System.err.println("Page did not load within " + DEFAULT_TIMEOUT + " seconds: " + e.getMessage());
        }
    }
    
    /**
     * Waits for a specific duration (use sparingly, prefer explicit waits)
     * 
     * @param seconds - Number of seconds to wait
     */
    public static void wait(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Wait interrupted: " + e.getMessage());
        }
    }
}
