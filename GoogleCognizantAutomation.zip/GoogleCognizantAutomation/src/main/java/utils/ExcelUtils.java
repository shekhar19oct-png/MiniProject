package utils;

import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.*;

/**
 * ExcelUtils - Utility class for reading data from Excel files using Apache POI
 * Uses relative paths for better portability
 * 
 * @author Automation Team
 * @version 1.0
 */
public class ExcelUtils {
    
    private static final String EXCEL_FILE_PATH = "src/resources/testdata/SearchData.xlsx";
    
    /**
     * Reads search text from Excel file
     * 
     * @return Search text from Excel, defaults to "Cognizant" if error occurs
     */
    public static String getSearchText() {
        try {
            FileInputStream fis = new FileInputStream(EXCEL_FILE_PATH);
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheetAt(0);
            
            // Read from row 1, column 0 (assuming row 0 is header)
            Row row = sheet.getRow(1);
            if (row == null) {
                System.err.println("Row 1 not found in Excel file");
                workbook.close();
                fis.close();
                return "Cognizant";
            }
            
            Cell cell = row.getCell(0);
            if (cell == null) {
                System.err.println("Cell at row 1, column 0 is empty");
                workbook.close();
                fis.close();
                return "Cognizant";
            }
            
            String searchText = cell.getStringCellValue();
            workbook.close();
            fis.close();
            
            System.out.println("Successfully read search text from Excel: " + searchText);
            return searchText;
            
        } catch (Exception e) {
            System.err.println("Error reading Excel file: " + e.getMessage());
            e.printStackTrace();
            System.out.println("Using default search text: Cognizant");
            return "Cognizant";
        }
    }
}
