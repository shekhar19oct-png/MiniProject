package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ConfigReader;

/**
 * BrowserFactory - Utility class for browser initialization
 * Handles multiple browser types (Chrome, Firefox) with proper exception handling
 * Uses WebDriverManager for automatic driver management
 * 
 * @author Automation Team
 * @version 1.0
 */
public class BrowserFactory {

    /**
     * Launches the specified browser and navigates to Google
     * 
     * @param browser - Browser name (chrome/firefox)
     * @return WebDriver instance
     * @throws Exception if browser initialization fails
     */
    public static WebDriver launchBrowser(String browser) throws Exception {
        WebDriver driver = null;
        
        try {
            if (browser == null || browser.isEmpty()) {
                browser = ConfigReader.getProperty("browser");
            }
            
            if (browser.equalsIgnoreCase("chrome")) {
                WebDriverManager.chromedriver().setup();
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--start-maximized");
                driver = new ChromeDriver(options);
            } else if (browser.equalsIgnoreCase("firefox")) {
                WebDriverManager.firefoxdriver().setup();
                FirefoxOptions options = new FirefoxOptions();
                driver = new FirefoxDriver(options);
                driver.manage().window().maximize();
            } else {
                throw new Exception("Unsupported browser: " + browser + ". Supported browsers: chrome, firefox");
            }
            
            // Navigate to URL from config
            String url = ConfigReader.getProperty("url");
            driver.get(url);
            
            System.out.println("Successfully launched " + browser + " browser and navigated to " + url);
            
        } catch (Exception e) {
            System.err.println("Error launching browser: " + e.getMessage());
            throw new Exception("Failed to launch browser: " + browser, e);
        }
        
        return driver;
    }
}
