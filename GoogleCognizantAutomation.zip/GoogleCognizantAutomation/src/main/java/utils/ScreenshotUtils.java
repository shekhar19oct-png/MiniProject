package utils;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.openqa.selenium.*;
import org.openqa.selenium.io.FileHandler;

/**
 * ScreenshotUtils - Utility class for taking screenshots
 * Supports both normal and full page screenshots
 * Uses relative paths and timestamps for better organization
 * 
 * @author Automation Team
 * @version 1.0
 */
public class ScreenshotUtils {
    
    private static final String SCREENSHOT_DIR = "screenshots";
    
    /**
     * Takes a normal screenshot of the visible viewport
     * 
     * @param driver - WebDriver instance
     * @param fileName - Name of the screenshot file (without extension)
     */
    public static void takeScreenshot(WebDriver driver, String fileName) {
        try {
            // Create screenshots directory if it doesn't exist
            File dir = new File(SCREENSHOT_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            
            File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String filePath = SCREENSHOT_DIR + File.separator + fileName + "_" + timestamp + ".png";
            FileHandler.copy(src, new File(filePath));
            
            System.out.println("Screenshot saved: " + filePath);
            
        } catch (Exception e) {
            System.err.println("Error taking screenshot: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Takes a full page screenshot using JavaScript
     * Scrolls through the entire page and captures it
     * 
     * @param driver - WebDriver instance
     * @param fileName - Name of the screenshot file (without extension)
     */
    public static void takeFullPageScreenshot(WebDriver driver, String fileName) {
        try {
            // Create screenshots directory if it doesn't exist
            File dir = new File(SCREENSHOT_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            
            // Get page dimensions using JavaScript
            JavascriptExecutor js = (JavascriptExecutor) driver;
            Long pageHeight = (Long) js.executeScript("return document.body.scrollHeight");
            Long viewportHeight = (Long) js.executeScript("return window.innerHeight");
            
            // Scroll and capture
            Long currentPosition = 0L;
            int screenshotNumber = 0;
            
            while (currentPosition < pageHeight) {
                // Scroll to current position
                js.executeScript("window.scrollTo(0, " + currentPosition + ");");
                
                // Wait a bit for page to settle
                Thread.sleep(500);
                
                // Take screenshot
                File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
                String filePath = SCREENSHOT_DIR + File.separator + fileName + "_full_" + timestamp + "_part" + screenshotNumber + ".png";
                FileHandler.copy(src, new File(filePath));
                
                System.out.println("Full page screenshot part " + screenshotNumber + " saved: " + filePath);
                
                currentPosition += viewportHeight;
                screenshotNumber++;
            }
            
            // Scroll back to top
            js.executeScript("window.scrollTo(0, 0);");
            
            // Also take a single full page attempt (works for Chrome)
            try {
                File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
                String filePath = SCREENSHOT_DIR + File.separator + fileName + "_full_" + timestamp + ".png";
                FileHandler.copy(src, new File(filePath));
                System.out.println("Full page screenshot saved: " + filePath);
            } catch (Exception e) {
                System.out.println("Note: Single full page screenshot not available, using scroll method");
            }
            
        } catch (Exception e) {
            System.err.println("Error taking full page screenshot: " + e.getMessage());
            e.printStackTrace();
            // Fallback to normal screenshot
            takeScreenshot(driver, fileName);
        }
    }
}
