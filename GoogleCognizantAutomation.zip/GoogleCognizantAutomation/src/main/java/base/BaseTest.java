package base;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import utils.BrowserFactory;

/**
 * BaseTest - Base class for all test classes
 * Handles browser setup and teardown with proper exception handling
 * 
 * @author Automation Team
 * @version 1.0
 */
public class BaseTest {

    protected WebDriver driver;

    /**
     * Setup method - Launches browser before each test
     * 
     * @param browser - Browser name from testng.xml parameters
     */
    @Parameters("browser")
    @BeforeMethod
    public void setup(String browser) {
        try {
            System.out.println("=========================================");
            System.out.println("Setting up browser: " + browser);
            System.out.println("=========================================");
            driver = BrowserFactory.launchBrowser(browser);
        } catch (Exception e) {
            System.err.println("Failed to setup browser: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Browser setup failed", e);
        }
    }

    /**
     * Teardown method - Closes browser after each test
     */
    @AfterMethod
    public void tearDown() {
        try {
            if (driver != null) {
                System.out.println("=========================================");
                System.out.println("Closing browser...");
                System.out.println("=========================================");
                driver.quit();
                System.out.println("Browser closed successfully");
            }
        } catch (Exception e) {
            System.err.println("Error closing browser: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
