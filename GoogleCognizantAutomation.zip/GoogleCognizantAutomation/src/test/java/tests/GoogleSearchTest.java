package tests;

import org.testng.annotations.Test;
import base.BaseTest;
import pages.GoogleHomePage;
import pages.GoogleSearchResultsPage;
import utils.ExcelUtils;
import utils.ScreenshotUtils;
import utils.WaitUtils;

/**
 * GoogleSearchTest - Test class for Google Cognizant search automation
 * Implements all requirements step by step
 * 
 * @author Automation Team
 * @version 1.0
 */
public class GoogleSearchTest extends BaseTest {

    /**
     * Main test method - Implements all requirements
     * Step 1: Find and print all links on Google home page
     * Step 2: Type "Cognizant" in search box
     * Step 3: Find and print search suggestions, take screenshot
     * Step 4: Click search button
     * Step 5: Get result count and take full page screenshot
     * Step 6: Navigate through All, News, Images, Videos tabs
     */
    @Test
    public void cognizantGoogleSearchTest() {
        try {
            System.out.println("=========================================");
            System.out.println("Starting Google Cognizant Search Test");
            System.out.println("=========================================");

            // Initialize Page Objects
            GoogleHomePage googleHomePage = new GoogleHomePage(driver);
            GoogleSearchResultsPage searchResultsPage;

            // Step 1: Find the number of links in the web page and print all link names
            System.out.println("\n--- Step 1: Finding all links on Google home page ---");
            googleHomePage.findAllLinks();
            WaitUtils.wait(1);

            // Step 2: Type "Cognizant" in search text box (from Excel)
            System.out.println("\n--- Step 2: Typing search text ---");
            String searchText = ExcelUtils.getSearchText();
            googleHomePage.typeSearchText(searchText);
            WaitUtils.wait(2);

            // Step 3: Find the number of search options displayed, take screenshot, and print all search options
            System.out.println("\n--- Step 3: Finding search suggestions ---");
            googleHomePage.findAndPrintSuggestions();
            ScreenshotUtils.takeScreenshot(driver, "SearchSuggestions");
            System.out.println("Screenshot taken: Search suggestions displayed");

            // Step 4: Click on Google Search button
            System.out.println("\n--- Step 4: Clicking Google Search button ---");
            googleHomePage.clickSearchButton();
            WaitUtils.wait(2);

            // Initialize search results page
            searchResultsPage = new GoogleSearchResultsPage(driver);

            // Step 5: Find the number of search results displayed as "About XXXXX results"
            System.out.println("\n--- Step 5: Getting search results count ---");
            String resultCount = searchResultsPage.getResultCount();
            System.out.println("Search results count: " + resultCount);

            // Step 6: Click "All" in Google, display count, take full page screenshot
            System.out.println("\n--- Step 6: Clicking 'All' tab ---");
            searchResultsPage.clickAllTab();
            ScreenshotUtils.takeFullPageScreenshot(driver, "AllResults");

            // Step 7: Click "News" in Google, display count, take full page screenshot
            System.out.println("\n--- Step 7: Clicking 'News' tab ---");
            String newsCount = searchResultsPage.clickNewsTab();
            System.out.println("News results count displayed in console: " + newsCount);
            ScreenshotUtils.takeFullPageScreenshot(driver, "NewsResults");

            // Step 8: Click "Images" in Google, take full page screenshot
            System.out.println("\n--- Step 8: Clicking 'Images' tab ---");
            searchResultsPage.clickImagesTab();
            ScreenshotUtils.takeFullPageScreenshot(driver, "ImagesResults");

            // Step 9: Click "Videos" in Google, display count, take full page screenshot
            System.out.println("\n--- Step 9: Clicking 'Videos' tab ---");
            String videosCount = searchResultsPage.clickVideosTab();
            System.out.println("Videos results count displayed in console: " + videosCount);
            ScreenshotUtils.takeFullPageScreenshot(driver, "VideosResults");

            System.out.println("\n=========================================");
            System.out.println("Test completed successfully!");
            System.out.println("=========================================");

        } catch (Exception e) {
            System.err.println("Test failed with error: " + e.getMessage());
            e.printStackTrace();
            
            // Take screenshot on failure
            try {
                ScreenshotUtils.takeScreenshot(driver, "TestFailure");
            } catch (Exception screenshotException) {
                System.err.println("Failed to take failure screenshot: " + screenshotException.getMessage());
            }
            
            throw new RuntimeException("Test execution failed", e);
        }
    }
}
