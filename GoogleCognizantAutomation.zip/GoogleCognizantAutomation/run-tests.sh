#!/bin/bash

# Google Cognizant Automation - Test Runner Script
# This script helps you run the tests easily

echo "========================================="
echo "Google Cognizant Automation - Test Runner"
echo "========================================="
echo ""

# Check Java
echo "Checking Java installation..."
if command -v java &> /dev/null; then
    java -version
    echo "✅ Java is installed"
else
    echo "❌ Java is NOT installed"
    echo "Please install Java JDK 11 or higher"
    echo "macOS: brew install openjdk@11"
    echo "Or download from: https://www.oracle.com/java/technologies/downloads/"
    exit 1
fi

echo ""

# Check Maven
echo "Checking Maven installation..."
if command -v mvn &> /dev/null; then
    mvn --version
    echo "✅ Maven is installed"
else
    echo "❌ Maven is NOT installed"
    echo "Please install Maven:"
    echo "macOS: brew install maven"
    echo "Or download from: https://maven.apache.org/download.cgi"
    exit 1
fi

echo ""
echo "========================================="
echo "Starting test execution..."
echo "========================================="
echo ""

# Navigate to project directory
cd "$(dirname "$0")"

# Clean and compile
echo "Step 1: Cleaning and compiling..."
mvn clean compile

if [ $? -ne 0 ]; then
    echo "❌ Compilation failed. Please check errors above."
    exit 1
fi

echo ""
echo "Step 2: Running tests..."
echo ""

# Run tests
mvn test

# Check result
if [ $? -eq 0 ]; then
    echo ""
    echo "========================================="
    echo "✅ Tests completed successfully!"
    echo "========================================="
    echo ""
    echo "Check the following for results:"
    echo "- Console output above for detailed logs"
    echo "- screenshots/ folder for screenshots"
    echo "- target/surefire-reports/ for test reports"
else
    echo ""
    echo "========================================="
    echo "❌ Tests failed. Check errors above."
    echo "========================================="
    exit 1
fi
